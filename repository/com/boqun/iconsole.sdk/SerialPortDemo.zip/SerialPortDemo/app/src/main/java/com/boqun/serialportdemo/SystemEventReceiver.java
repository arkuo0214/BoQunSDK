package com.boqun.serialportdemo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

public class SystemEventReceiver extends BroadcastReceiver {

    private Callback callback;

    private boolean isRegister = false;


    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) {
            return;
        }
        String action = intent.getAction();

        if (Intent.ACTION_SCREEN_ON.equals(action)) {
            callback.onScreenOn();
        } else if (Intent.ACTION_SCREEN_OFF.equals(action)) {
            callback.onScreenOff();
        } else if (Intent.ACTION_SHUTDOWN.equals(action)) {
            callback.onShutdown();
        }
    }

    public void register(Context context, Callback callback) {
        this.callback = callback;
        if (!isRegister) {
            isRegister = true;
            IntentFilter filter = new IntentFilter();
            filter.addAction(Intent.ACTION_SCREEN_OFF);
            filter.addAction(Intent.ACTION_SCREEN_ON);
            filter.addAction(Intent.ACTION_SHUTDOWN);
            filter.addAction(Intent.ACTION_BOOT_COMPLETED);
            context.registerReceiver(this, filter);
        }
    }

    public void unregister(Context context) {
        if (isRegister) {
            isRegister = false;
            context.unregisterReceiver(this);
            this.callback = null;
        }
    }

    public interface Callback {

        void onScreenOn();

        void onScreenOff();

        void onShutdown();
    }
}
