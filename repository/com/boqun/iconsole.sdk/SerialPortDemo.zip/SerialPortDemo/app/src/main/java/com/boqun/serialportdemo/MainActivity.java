package com.boqun.serialportdemo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.boqun.serialportdemo.bike.BikeActivity;
import com.boqun.serialportdemo.rower.RowerActivity;
import com.boqun.serialportdemo.treadmill.TreadmillActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = MainActivity.class.getSimpleName();

    private Button mBtBikeTest;
    private Button mBtTreadmillTest;
    private Button mBtRowerTest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        mBtBikeTest = findViewById(R.id.mBtBikeTest);
        mBtTreadmillTest = findViewById(R.id.mBtTreadmillTest);
        mBtRowerTest = findViewById(R.id.mBtRowerTest);

        mBtBikeTest.setOnClickListener(this);
        mBtTreadmillTest.setOnClickListener(this);
        mBtRowerTest.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.mBtBikeTest) {
            startActivity(new Intent(this, BikeActivity.class));
        } else if (id == R.id.mBtTreadmillTest) {
            startActivity(new Intent(this, TreadmillActivity.class));
        } else if (id == R.id.mBtRowerTest) {
            startActivity(new Intent(this, RowerActivity.class));
        }
    }

}
