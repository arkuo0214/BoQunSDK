package com.boqun.serialportdemo.treadmill;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.boqun.iconsole.sdk.AutoCorrectionState;
import com.boqun.iconsole.sdk.treadmill.BoQunTreadmillFactory;
import com.boqun.iconsole.sdk.treadmill.TreadmillFactoryInfo;
import com.boqun.iconsole.sdk.treadmill.TreadmillFactoryType;
import com.boqun.iconsole.sdk.treadmill.impl.OnTreadmillFactoryListener;
import com.boqun.serialportdemo.BaseActivity;
import com.boqun.serialportdemo.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
//import com.boqun.uart.treadmill.BoQunTreadmill;
//import com.boqun.uart.treadmill.CorrectionState;
//import com.boqun.uart.treadmill.FactoryDataBean;
//import com.boqun.uart.treadmill.FactoryParams;
//import com.boqun.uart.treadmill.TreadmillFactory;

public class TreadmillFactoryActivity extends BaseActivity implements View.OnClickListener {

    private RecyclerView mRvData;

    private Button mBtAutoCal;

    private FactoryParamsListAdapter mAdapter = null;

    private boolean isAutoCalibration = false;

    private AlertDialog mInclineAutoCalDialog = null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.treadmill_factory_layout);

        initActionBar("Treadmill Factory", true);

        initViews();

        initListAdapter();

        final Map<Integer, String> titleMap = new HashMap<>();
        titleMap.put(TreadmillFactoryInfo.TYPE_WHEEL_DIAMETER, "轮径");
        titleMap.put(TreadmillFactoryInfo.TYPE_LIGHT_PERCEPTION_RATIO, "光感配比");
        titleMap.put(TreadmillFactoryInfo.TYPE_MAX_INCLINE_VR, "扬升VR最大值");
        titleMap.put(TreadmillFactoryInfo.TYPE_MIN_INCLINE_VR, "扬升VR最小值");
        titleMap.put(TreadmillFactoryInfo.TYPE_MIN_SPEED, "最低速度");
        titleMap.put(TreadmillFactoryInfo.TYPE_MAX_SPEED, "最高速度");
        titleMap.put(TreadmillFactoryInfo.TYPE_MIN_INCLINE, "最低扬升");
        titleMap.put(TreadmillFactoryInfo.TYPE_MAX_INCLINE, "最大扬升");
        titleMap.put(TreadmillFactoryInfo.TYPE_TORQUE, "扭力值");
        titleMap.put(TreadmillFactoryInfo.TYPE_INCLINE_SWITCH, "公英里切换");
        titleMap.put(TreadmillFactoryInfo.TYPE_LINE_CURRENT, "限电流值");
        titleMap.put(TreadmillFactoryInfo.TYPE_TEN_KM_VOLTAGE, "10公里电压值");
        titleMap.put(TreadmillFactoryInfo.TYPE_ONE_KM_VOLTAGE, "1公里电压值");
        titleMap.put(TreadmillFactoryInfo.TYPE_CHILD_SPEED, "速度增量");
        titleMap.put(TreadmillFactoryInfo.TYPE_PA_PB, "温度电感");
        titleMap.put(TreadmillFactoryInfo.TYPE_MOTOR_INIT_PULSE, "马达起始PULSE");
        titleMap.put(TreadmillFactoryInfo.TYPE_INDUCTION_METHOD, "有感/无感扬升");

        BoQunTreadmillFactory.init();

        BoQunTreadmillFactory.queryFactoryInfo();

        BoQunTreadmillFactory.setOnTreadmillFactoryListener(new OnTreadmillFactoryListener() {
            @Override
            public void onResponseFactoryInfo(TreadmillFactoryInfo info) {
                List<ItemModel> models = new ArrayList<>();
                for (Map.Entry<Integer, Integer> entry : info.toMaps().entrySet()) {
                    models.add(new ItemModel(entry.getKey(), titleMap.get(entry.getKey()), entry.getValue()));
                }

                mAdapter.clear();
                mAdapter.addData(models);

                Log.d("TAG", "onResponseFactoryInfo: " + info.toString());
            }

            @Override
            public void onResponseMotorAutoCorrection(int status, int speed, int adc, int inclineVR) {
                if (status == AutoCorrectionState.CORRECTION_START) {
                    mInclineAutoCalDialog.getButton(DialogInterface.BUTTON_POSITIVE).setText("Stop");
                } else if (mInclineAutoCalDialog.isShowing() && status == AutoCorrectionState.CORRECTION_ING) {
                    TextView tv = mInclineAutoCalDialog.findViewById(R.id.mTvMsg);
                    if (tv != null) {
                        tv.setText("SPEED: " + speed + " ，MOTOR ADC: " + adc + " ，INCLINE VR: " + inclineVR);
                    }
                } else if (status == AutoCorrectionState.CORRECTION_STOP) {
                    mInclineAutoCalDialog.getButton(DialogInterface.BUTTON_POSITIVE).setText("Start");
                }
                Log.d("TAG", "onResponseMotorAutoCal: " + status + "  speed:" + speed + "  adc:" + adc + "   incline:" + inclineVR);
            }
        });

    }

    private void initViews() {
        mBtAutoCal = findViewById(R.id.mBtAutoCal);
        mRvData = findViewById(R.id.mRvData);

        mBtAutoCal.setOnClickListener(this);
    }

    private void initListAdapter() {
        mAdapter = new FactoryParamsListAdapter();

        mRvData.setLayoutManager(new GridLayoutManager(getContext(), 2));
        mRvData.setAdapter(mAdapter);

        mAdapter.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(final View v, final int position) {
                final ItemModel model = mAdapter.getData().get(position);

                final EditText editView = new EditText(getContext());
                editView.setFilters(new InputFilter[]{new InputFilter.LengthFilter(3)});
                editView.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_NORMAL);
                editView.setImeOptions(EditorInfo.IME_ACTION_DONE);
                editView.setMaxLines(1);

                new AlertDialog.Builder(getContext())
                        .setTitle(model.getTitle())
                        .setView(editView)
                        .setNegativeButton("取消", null)
                        .setPositiveButton("确认", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                String text = editView.getText().toString();
                                if (!TextUtils.isEmpty(text)) {
                                    int value = Integer.parseInt(text);
                                    BoQunTreadmillFactory.setFactoryInfo(model.getCode(), value);
                                    model.setValue(value);
                                    mAdapter.setData(position, model);
                                }
                            }
                        }).show();
            }
        });
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.mBtAutoCal) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Speed And Incline Automatic calibration");
            builder.setView(R.layout.msg_text_layout);
            builder.setCancelable(false);
            builder.setPositiveButton("Start", null);
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    BoQunTreadmillFactory.stopAutoCorrection();
                }
            });
            mInclineAutoCalDialog = builder.create();
            mInclineAutoCalDialog.show();
            mInclineAutoCalDialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String text = mInclineAutoCalDialog.getButton(DialogInterface.BUTTON_POSITIVE).getText().toString();
                    if ("Start".equals(text)) {
                        BoQunTreadmillFactory.startAutoCorrection();
                    } else {
                        BoQunTreadmillFactory.stopAutoCorrection();
                    }
                }
            });

        }
    }

    @Override
    protected void onDestroy() {

        BoQunTreadmillFactory.destroy();
        super.onDestroy();
    }

    public static class FactoryParamsListAdapter extends RecyclerView.Adapter<FactoryParamsListAdapter.ViewHolder> {

        private final List<ItemModel> mData = new ArrayList<>();

        private OnItemClickListener onItemClickListener;

        @SuppressLint("NotifyDataSetChanged")
        public void clear() {
            mData.clear();
            notifyDataSetChanged();
        }

        public void addData(List<ItemModel> map) {
            int oldSize = getData().size();
            mData.addAll(map);
            notifyItemRangeInserted(oldSize, getData().size() - 1);
        }

        public void setData(int position, ItemModel model) {
            mData.set(position, model);
            notifyItemChanged(position);
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            ViewHolder holder = new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.treadmill_factory_params_item, parent, false));
            holder.setOnItemClickListener(onItemClickListener);
            return holder;
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            ItemModel params = getData().get(position);
            holder.mTvTitle.setText(params.getTitle());
            holder.mTvValue.setText(String.valueOf(params.getValue()));

        }

        @Override
        public int getItemCount() {
            return mData.size();
        }

        public List<ItemModel> getData() {
            return mData;
        }

        public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
            this.onItemClickListener = onItemClickListener;
        }

        public static class ViewHolder extends RecyclerView.ViewHolder {

            TextView mTvTitle;
            TextView mTvValue;
            Button mBtSetValue;

            private OnItemClickListener onItemClickListener;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                mTvTitle = itemView.findViewById(R.id.mTvTitle);
                mTvValue = itemView.findViewById(R.id.mTvValue);
                mBtSetValue = itemView.findViewById(R.id.mBtSetValue);

                mBtSetValue.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (onItemClickListener != null) {
                            onItemClickListener.onItemClick(view, getAdapterPosition());
                        }
                    }
                });
            }

            public void setOnItemClickListener(OnItemClickListener listener) {
                this.onItemClickListener = listener;
            }
        }
    }

    public static class ItemModel {

        public int code;

        public String title;

        public int value;

        public ItemModel(int code, String title, int value) {
            this.code = code;
            this.title = title;
            this.value = value;


        }

        @TreadmillFactoryType
        public int getCode() {
            return code;
        }

        public String getTitle() {
            return title;
        }

        public int getValue() {
            return value;
        }

        public void setValue(int value) {
            this.value = value;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            ItemModel params = (ItemModel) o;
            return Objects.equals(code, params.code);
        }

        @Override
        public int hashCode() {
            return Objects.hash(code);
        }

    }

    public interface OnItemClickListener {

        void onItemClick(View v, int position);

    }

}
