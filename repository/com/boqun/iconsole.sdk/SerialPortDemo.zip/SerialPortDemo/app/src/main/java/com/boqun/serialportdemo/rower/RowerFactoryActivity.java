package com.boqun.serialportdemo.rower;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;

import com.boqun.iconsole.sdk.rower.BoQunRowerFactory;
import com.boqun.iconsole.sdk.rower.RowerFactoryInfo;
import com.boqun.iconsole.sdk.rower.RowerMotorStatus;
import com.boqun.iconsole.sdk.rower.RowerRepairDirection;
import com.boqun.iconsole.sdk.rower.impl.OnRowerFactoryListener;
import com.boqun.serialportdemo.BaseActivity;
import com.boqun.serialportdemo.R;
import com.boqun.serialportdemo.ToastUtil;

public class RowerFactoryActivity extends BaseActivity implements View.OnClickListener {

    private static final String TAG = RowerFactoryActivity.class.getSimpleName();

    private LinearLayout mLiDiameter;
    private TextView mTvDiameterValue;
    private LinearLayout mLiMagnet;
    private TextView mTvMagnetValue;
    private LinearLayout mLiDistance;
    private TextView mTvDistanceValue;
    private LinearLayout mLiCalories;
    private TextView mTvCaloriesValue;
    private LinearLayout mLiPer500MTime;
    private TextView mTvPer500MTimeValue;
    private TextView mTvSaveParameters;
    private ImageView mIvR2RLoadDown;
    private TextView mTvR2RLoadValue;
    private ImageView mIvR2RLoadUp;
    private ImageView mIvR2RAdcDown;
    private TextView mTvR2RAdcValue;
    private ImageView mIvR2RAdcUp;
    private TextView mTvSaveR2R;
    private TextView mTvMotorReturnStatus;
    private Button mBtMotorReturnCorrection;

    private int mMotorStatus = 0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rower_factory_layout);

        initActionBar("Rower Machine Factory", true);

        initViews();

        BoQunRowerFactory.init();

        BoQunRowerFactory.queryFactoryInfo();

        BoQunRowerFactory.queryLoadMotorStroke(1);

        BoQunRowerFactory.setOnRowerFactoryListener(new OnRowerFactoryListener() {

            @Override
            public void onResponseFactoryInfo(RowerFactoryInfo info) {
                mTvDiameterValue.setText(String.valueOf(info.getDiameter()));
                mTvMagnetValue.setText(String.valueOf(info.getMagnet()));
                mTvDistanceValue.setText(String.valueOf(info.getDistance()));
                mTvCaloriesValue.setText(String.valueOf(info.getCalories()));
                mTvPer500MTimeValue.setText(String.valueOf(info.getTimePer500m()));
            }

            @Override
            public void onResponseLoadMotorStroke(int load, int adc) {
                mTvR2RLoadValue.setText(String.valueOf(load));
                mTvR2RAdcValue.setText(String.valueOf(adc));
            }

            @Override
            public void onResponseMotorStatus(int status) {
                mMotorStatus = status;
                mBtMotorReturnCorrection.setEnabled(status != 0);
                if (mMotorStatus == RowerMotorStatus.NORMAL) {
                    mTvMotorReturnStatus.setText("Normal");
                } else if (mMotorStatus == RowerMotorStatus.ERROR_UP) {
                    mTvMotorReturnStatus.setText("Error up");
                } else if (mMotorStatus == RowerMotorStatus.ERROR_DOWN) {
                    mTvMotorReturnStatus.setText("Error down");
                }
            }
        });
    }

    private void initViews() {

        mLiDiameter = findViewById(R.id.mLiDiameter);
        mTvDiameterValue = findViewById(R.id.mTvDiameterValue);
        mLiMagnet = findViewById(R.id.mLiMagnet);
        mTvMagnetValue = findViewById(R.id.mTvMagnetValue);
        mLiDistance = findViewById(R.id.mLiDistance);
        mTvDistanceValue = findViewById(R.id.mTvDistanceValue);
        mLiCalories = findViewById(R.id.mLiCalories);
        mTvCaloriesValue = findViewById(R.id.mTvCaloriesValue);
        mLiPer500MTime = findViewById(R.id.mLiPer500MTime);
        mTvPer500MTimeValue = findViewById(R.id.mTvPer500MTimeValue);
        mTvSaveParameters = findViewById(R.id.mTvSaveParameters);
        mIvR2RLoadDown = findViewById(R.id.mIvR2RLoadDown);
        mTvR2RLoadValue = findViewById(R.id.mTvR2RLoadValue);
        mIvR2RLoadUp = findViewById(R.id.mIvR2RLoadUp);
        mIvR2RAdcDown = findViewById(R.id.mIvR2RAdcDown);
        mTvR2RAdcValue = findViewById(R.id.mTvR2RAdcValue);
        mIvR2RAdcUp = findViewById(R.id.mIvR2RAdcUp);
        mTvSaveR2R = findViewById(R.id.mTvSaveR2R);
        mTvMotorReturnStatus = findViewById(R.id.mTvMotorReturnStatus);
        mBtMotorReturnCorrection = findViewById(R.id.mBtMotorReturnCorrection);

        mLiDiameter.setOnClickListener(this);
        mLiMagnet.setOnClickListener(this);
        mLiDistance.setOnClickListener(this);
        mLiCalories.setOnClickListener(this);
        mLiPer500MTime.setOnClickListener(this);
        mTvSaveParameters.setOnClickListener(this);
        mIvR2RLoadDown.setOnClickListener(this);
        mIvR2RLoadUp.setOnClickListener(this);
        mIvR2RAdcDown.setOnClickListener(this);
        mIvR2RAdcUp.setOnClickListener(this);
        mTvSaveR2R.setOnClickListener(this);
        mTvMotorReturnStatus.setOnClickListener(this);
        mBtMotorReturnCorrection.setOnClickListener(this);

    }


    @Override
    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.mLiDiameter) {
            editFactoryParams(mTvDiameterValue, "Diameter");
        } else if (id == R.id.mLiMagnet) {
            editFactoryParams(mTvMagnetValue, "Magnet");
        } else if (id == R.id.mLiDistance) {
            editFactoryParams(mTvDistanceValue, "Distance");
        } else if (id == R.id.mLiCalories) {
            editFactoryParams(mTvCaloriesValue, "Calories");
        } else if (id == R.id.mLiPer500MTime) {
            editFactoryParams(mTvPer500MTimeValue, "TIME/500");
        } else if (id == R.id.mTvSaveParameters) {
            int diameter = Integer.parseInt(mTvDiameterValue.getText().toString());
            int magnet = Integer.parseInt(mTvMagnetValue.getText().toString());
            int distance = Integer.parseInt(mTvDistanceValue.getText().toString());
            int calories = Integer.parseInt(mTvCaloriesValue.getText().toString());
            int timePer500m = Integer.parseInt(mTvPer500MTimeValue.getText().toString());

            RowerFactoryInfo info = new RowerFactoryInfo();
            info.setDiameter(diameter);
            info.setMagnet(magnet);
            info.setDistance(distance);
            info.setCalories(calories);
            info.setTimePer500m(timePer500m);
            BoQunRowerFactory.setFactoryInfo(info);
            ToastUtil.show(getContext(), "Saved！");
        } else if (id == R.id.mIvR2RLoadDown) {
            int load = setLoadMotorStroke(mTvR2RLoadValue, MachineInfo.getMinLoad(), MachineInfo.getMaxLoad(), -1);
            BoQunRowerFactory.queryLoadMotorStroke(load);
        } else if (id == R.id.mIvR2RLoadUp) {
            int load = setLoadMotorStroke(mTvR2RLoadValue, MachineInfo.getMinLoad(), MachineInfo.getMaxLoad(), 1);
            BoQunRowerFactory.queryLoadMotorStroke(load);
        } else if (id == R.id.mIvR2RAdcDown) {
            setLoadMotorStroke(mTvR2RAdcValue, 0, 999, -1);
        } else if (id == R.id.mIvR2RAdcUp) {
            setLoadMotorStroke(mTvR2RAdcValue, 0, 999, 1);
        } else if (id == R.id.mTvSaveR2R) {
            int load = Integer.parseInt(mTvR2RLoadValue.getText().toString());
            int adc = Integer.parseInt(mTvR2RAdcValue.getText().toString());
            BoQunRowerFactory.setLoadMotorStroke(load, adc);
        } else if (id == R.id.mBtMotorReturnCorrection) {
            if (mMotorStatus == RowerMotorStatus.ERROR_UP) {
                BoQunRowerFactory.setRepairDirection(RowerRepairDirection.UP);
            } else if (mMotorStatus == RowerMotorStatus.ERROR_DOWN) {
                BoQunRowerFactory.setRepairDirection(RowerRepairDirection.DOWN);
            }
        }
    }


    private void editFactoryParams(final TextView view, String title) {

        final EditText editView = new EditText(getContext());
        editView.setFilters(new InputFilter[]{new InputFilter.LengthFilter(3)});
        editView.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_NORMAL);
        editView.setImeOptions(EditorInfo.IME_ACTION_DONE);
        editView.setMaxLines(1);

        new AlertDialog.Builder(getContext())
                .setTitle(title)
                .setView(editView)
                .setNegativeButton("取消", null)
                .setPositiveButton("确认", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String text = editView.getText().toString();
                        if (TextUtils.isEmpty(text)) {
                            text = "0";
                        }
                        view.setText(text);
                    }
                }).show();
    }

    private int setLoadMotorStroke(TextView view, int min, int max, int value) {
        int load = Integer.parseInt(view.getText().toString());
        int v = load + value;
        if (v < min) {
            v = min;
        } else if (v > max) {
            v = max;
        }
        view.setText(String.valueOf(v));
        return v;
    }

    @Override
    protected void onDestroy() {

        BoQunRowerFactory.destroy();

        super.onDestroy();
    }
}
