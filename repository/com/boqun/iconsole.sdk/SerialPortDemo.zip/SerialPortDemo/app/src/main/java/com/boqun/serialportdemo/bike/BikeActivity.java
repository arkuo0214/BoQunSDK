package com.boqun.serialportdemo.bike;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.boqun.iconsole.sdk.ErrorCode;
import com.boqun.iconsole.sdk.bike.BikeConfigInfo;
import com.boqun.iconsole.sdk.bike.BikeKeyCode;
import com.boqun.iconsole.sdk.bike.BikeSportState;
import com.boqun.iconsole.sdk.bike.BikeWorkMode;
import com.boqun.iconsole.sdk.bike.BoQunBike;
import com.boqun.iconsole.sdk.bike.impl.OnBikeListener;
import com.boqun.serialportdemo.BaseActivity;
import com.boqun.serialportdemo.R;
import com.boqun.serialportdemo.SystemEventReceiver;

import java.util.Locale;

public class BikeActivity extends BaseActivity implements View.OnClickListener {

    private static final String TAG = BikeActivity.class.getSimpleName();

    private TextView mTvInitValue;
    private TextView mTvLoadValue;
    private TextView mTvInclineValue;
    private Button mBtFactory;
    private TextView mTvSportValue;
    private Button mBtLoadUp;
    private Button mBtLoadDown;
    private Button mBtStartAndPause;
    private Button mBtStop;
    private Button mBtInclineUp;
    private Button mBtInclineDown;
    private Button mBtFan;
    private Button mBtEnableRead;
    private Button mBtDisableRead;

    private SystemEventReceiver mSystemEventReceiver;

    private int currentFanLevel = 0;

    private int currentLoad = 0, currentIncline = 0;

    private AlertDialog mHintDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bike_layout);

        initActionBar("Bike", true);

        mTvInitValue = findViewById(R.id.mTvInitValue);
        mTvLoadValue = findViewById(R.id.mTvLoadValue);
        mTvInclineValue = findViewById(R.id.mTvInclineValue);
        mBtFactory = findViewById(R.id.mBtFactory);
        mTvSportValue = findViewById(R.id.mTvSportValue);
        mBtLoadUp = findViewById(R.id.mBtLoadUp);
        mBtLoadDown = findViewById(R.id.mBtLoadDown);
        mBtStartAndPause = findViewById(R.id.mBtStartAndPause);
        mBtStop = findViewById(R.id.mBtStop);
        mBtInclineUp = findViewById(R.id.mBtInclineUp);
        mBtInclineDown = findViewById(R.id.mBtInclineDown);
        mBtFan = findViewById(R.id.mBtFan);
        mBtEnableRead = findViewById(R.id.mBtEnableRead);
        mBtDisableRead = findViewById(R.id.mBtDisableRead);

        mBtStartAndPause.setOnClickListener(this);
        mBtStop.setOnClickListener(this);
        mBtLoadUp.setOnClickListener(this);
        mBtLoadDown.setOnClickListener(this);
        mBtInclineUp.setOnClickListener(this);
        mBtInclineDown.setOnClickListener(this);
        mBtFactory.setOnClickListener(this);
        mBtFan.setOnClickListener(this);
        mBtEnableRead.setOnClickListener(this);
        mBtDisableRead.setOnClickListener(this);


        BoQunBike.init(new OnBikeListener() {
            @Override
            public void onResponseConfigInfo(BikeConfigInfo info) {
                MachineInfo.setClientId(info.getClientId());
                MachineInfo.setWattGroup(info.getWattGroup());
                MachineInfo.setWheelDiameter(info.getWheelDiameter());
                MachineInfo.setHasFan(info.hasFan());
                MachineInfo.setHasIncline(info.hasIncline());
                MachineInfo.setHasFTMS(info.hasFTMS());
                MachineInfo.setMinLoad(info.getMinLoadLevel());
                MachineInfo.setMaxLoad(info.getMaxLoadLevel());
                MachineInfo.setMinIncline(info.getMinInclineLevel());
                MachineInfo.setMaxIncline(info.getMaxInclineLevel());
                MachineInfo.setNegativeIncline(info.getNegativeInclineLevel());

                currentLoad = info.getMinLoadLevel();
                currentIncline = info.getMinInclineLevel();

                mBtFan.setEnabled(MachineInfo.hasFan());
                mBtInclineUp.setEnabled(MachineInfo.hasIncline());
                mBtInclineDown.setEnabled(MachineInfo.hasIncline());

                String text = new StringBuilder()
                        .append("\r\n").append("WATT Group： ").append(info.getWattGroup())
                        .append("\r\n").append("Wheel Diameter： ").append(info.getWheelDiameter())
                        .append("\r\n").append("Client ID： ").append(info.getClientId())
                        .append("\r\n").append("Min Load： ").append(info.getMinLoadLevel())
                        .append("\r\n").append("Max Load： ").append(info.getMaxLoadLevel())
                        .append("\r\n").append("Min Incline： ").append(info.getMinInclineLevel())
                        .append("\r\n").append("Max Incline： ").append(info.getMaxInclineLevel())
                        .append("\r\n").append("Has Fan： ").append((info.hasFan() ? "Yes" : "No"))
                        .append("\r\n").append("Has Incline： ").append((info.hasIncline() ? "Yes" : "No"))
                        .toString();

                mTvInitValue.setText(text);
                mTvLoadValue.setText("LOAD:" + currentLoad);
                mTvInclineValue.setText("INCLINE:" + currentIncline);

                Log.d(TAG, "onResponseConfigInfo: " + info.toString());
            }

            @Override
            public void onResponseSportStatus(int status) {
                Log.d(TAG, "onSportStatusChange: " + status);
                isSporting = status == BikeSportState.START;
                if (status == BikeSportState.START) {
                    mBtFactory.setEnabled(false);
                    mBtStartAndPause.setText("Pause");
                    mTvLoadValue.setText("LOAD:" + currentLoad);
                } else if (status == BikeSportState.PAUSE) {
                    mBtStartAndPause.setText("Start");
                    mBtFactory.setEnabled(false);
                    mTvLoadValue.setText("LOAD:" + MachineInfo.getMinLoad());
                } else if (status == BikeSportState.STOP) {
                    currentLoad = MachineInfo.getMinLoad();
                    currentIncline = MachineInfo.getMinIncline();
                    mTvLoadValue.setText("LOAD:" + currentLoad);
                    mTvInclineValue.setText("INCLINE:" + currentIncline);
                    mBtStartAndPause.setText("Start");
                    mTvSportValue.setText("");
                    mBtFactory.setEnabled(true);
                }
            }

            @Override
            public void onResponseSportData(int stepCount, int rpm, int heartRate) {
                StringBuilder builder = new StringBuilder();
                builder.append("\r\n").append("Step Count： ").append(stepCount);
                builder.append("\r\n").append("RPM Value:： ").append(rpm);
                builder.append("\r\n").append("PULSE Value： ").append(heartRate);

                mTvSportValue.setText(builder.toString());

                Log.d(TAG, "onResponseSportData--> stepCount:" + stepCount + "  rpm:" + rpm + " heartRate:" + heartRate);
            }

            @Override
            public void onResponseLoadLevel(int load) {
                currentLoad = load;
                mTvLoadValue.setText("LOAD:" + currentLoad);
                Log.d(TAG, "onResponseLoadLevel: " + load);
            }

            @Override
            public void onResponseInclineLevel(int incline) {
                currentIncline = incline;
                mTvInclineValue.setText("INCLINE:" + currentIncline);
                Log.d(TAG, "onResponseInclineLevel: " + incline);
            }

            @Override
            public void onResponseFanLevel(int level) {
                currentFanLevel = level;
                mBtFan.setText("FAN LEVEL:" + currentFanLevel);
            }

            @Override
            public void onExternalKeyEvent(int keyCode) {
                if (keyCode == BikeKeyCode.KEY_STOP) {
                    mBtStop.performClick();
                } else if (keyCode == BikeKeyCode.KEY_START_PAUSE) {
                    mBtStartAndPause.performClick();
                } else if (keyCode == BikeKeyCode.KEY_LOAD_UP) {
                    mBtLoadUp.performClick();
                } else if (keyCode == BikeKeyCode.KEY_LOAD_DOWN) {
                    mBtLoadDown.performClick();
                } else if (keyCode == BikeKeyCode.KEY_INCLINE_UP) {
                    mBtInclineUp.performClick();
                } else if (keyCode == BikeKeyCode.KEY_INCLINE_DOWN) {
                    mBtInclineDown.performClick();
                } else if (keyCode == BikeKeyCode.KEY_FAN) {
                    mBtFan.performClick();
                }
                Log.d(TAG, "onExternalKeyEvent: " + keyCode);
            }

            @Override
            public void onError(int errorCode) {
                Log.d(TAG, "onError: " + errorCode);
                if (mHintDialog == null && !isFinishing()) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                    builder.setTitle("Machine abnormal");
                    if (errorCode == ErrorCode.NO_RESPONSE) {
                        builder.setMessage("The machine parameters cannot be read. Please check whether the connection line is loose or whether the machine is matched with the lower control?");
                    } else if (errorCode == ErrorCode.CONFIG_EXCEPTION) {
                        builder.setMessage("Some parameters of the machine failed to read, it may not work properly!");
                    } else if (errorCode == ErrorCode.SERIAL_OPEN_FAILED) {
                        builder.setMessage("The device cannot use serial port for communication!");
                    }else {
                        builder.setMessage("Happen \"" + String.format(Locale.getDefault(), "%02x", errorCode).toUpperCase() + "\" Error, please refer to the error code to see the cause of the error.");
                    }
                    builder.setPositiveButton("Got it", null);
                    builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
                        @Override
                        public void onDismiss(DialogInterface dialogInterface) {
                            mHintDialog = null;
                        }
                    });
                    mHintDialog = builder.create();
                    mHintDialog.show();
                }

            }
        });

        BoQunBike.queryConfigInfo();

        //Get current Load
        BoQunBike.queryMachineInfo(BoQunBike.TYPE_LOAD_LEVEL);

        //Get current sport status
        BoQunBike.queryMachineInfo(BoQunBike.TYPE_SPORT_STATUS);

        mSystemEventReceiver = new SystemEventReceiver();
        mSystemEventReceiver.register(this, new SystemEventReceiver.Callback() {
            @Override
            public void onScreenOn() {
                Log.e(TAG, "onScreenOn");
                BoQunBike.setWorkMode(BikeWorkMode.NORMAL);
            }

            @Override
            public void onScreenOff() {
                Log.e(TAG, "onScreenOff");
                BoQunBike.setWorkMode(BikeWorkMode.SLEEP);
            }

            @Override
            public void onShutdown() {
                Log.e(TAG, "onShutdown");
                BoQunBike.setWorkMode(BikeWorkMode.SHUT_DOWN);
            }
        });
    }

    private boolean isSporting = false;

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.mBtStartAndPause) {
            if (!isSporting) {
                BoQunBike.start();
                BoQunBike.setLoadLevel(currentLoad);
                if (MachineInfo.hasIncline()) {
                    BoQunBike.setInclineLevel(currentIncline);
                }
            } else {
                BoQunBike.pause();
            }
            isSporting = !isSporting;
        } else if (id == R.id.mBtStop) {
            BoQunBike.stop();
            isSporting = false;
        } else if (id == R.id.mBtLoadUp) {
            if (currentLoad < MachineInfo.getMaxLoad()) {
                currentLoad += 1;
                BoQunBike.setLoadLevel(currentLoad);
            }
        } else if (id == R.id.mBtLoadDown) {
            if (currentLoad > MachineInfo.getMinLoad()) {
                currentLoad -= 1;
                BoQunBike.setLoadLevel(currentLoad);
            }
        } else if (id == R.id.mBtInclineUp) {
            if (currentIncline < MachineInfo.getMaxIncline()) {
                currentIncline += 1;
                BoQunBike.setInclineLevel(currentIncline);
            }
        } else if (id == R.id.mBtInclineDown) {
            if (currentIncline > MachineInfo.getMinIncline()) {
                currentIncline -= 1;
                BoQunBike.setInclineLevel(currentIncline);
            }
        } else if (id == R.id.mBtFan) {
            currentFanLevel = (currentFanLevel + 1) % 4;
            BoQunBike.setFanLevel(currentFanLevel);
        } else if (id == R.id.mBtFactory) {
            startActivity(new Intent(this, BikeFactoryActivity.class));
        } else if (id == R.id.mBtEnableRead) {
            BoQunBike.setSerialPortEnabled(true);
        } else if (id == R.id.mBtDisableRead) {
            BoQunBike.setSerialPortEnabled(false);
        }
    }


    public Context getContext() {
        return this;
    }


    @Override
    protected void onDestroy() {

        BoQunBike.destroy();

        if (mHintDialog != null && mHintDialog.isShowing()) {
            mHintDialog.dismiss();
        }

        if (mSystemEventReceiver != null) {
            mSystemEventReceiver.unregister(this);
            mSystemEventReceiver = null;
        }
        super.onDestroy();
    }
}
