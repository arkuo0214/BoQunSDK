package com.boqun.serialportdemo;

import android.app.Application;

import fly.serialport.uart.BoQun;

/**
 * @Description TODO
 * @Author Felix
 * @Date 2021/11/5 10:55
 */
public class App extends Application {

    private static final String APP_ID = "32b8986755805d3711d5c439b4111817";

    @Override
    public void onCreate() {
        super.onCreate();

        BoQun.createInstance(APP_ID, this);

    }
}
