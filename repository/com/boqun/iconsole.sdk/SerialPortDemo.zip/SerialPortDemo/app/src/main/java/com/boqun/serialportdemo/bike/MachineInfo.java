package com.boqun.serialportdemo.bike;

class MachineInfo {

    private static int minLoad = 1, maxLoad = 16;

    private static int minIncline = 0, maxIncline = 20, negativeIncline = 0;

    private static int wheelDiameter = 0;

    private static int clientId = 0;

    private static int wattGroup = 0;

    private static boolean hasIncline = false;

    private static boolean hasFan = false;

    private static boolean hasFTMS=false;

    public static int getMinLoad() {
        return minLoad;
    }

    public static void setMinLoad(int minLoad) {
        MachineInfo.minLoad = minLoad;
    }

    public static int getMaxLoad() {
        return maxLoad;
    }

    public static void setMaxLoad(int maxLoad) {
        MachineInfo.maxLoad = maxLoad;
    }

    public static int getMinIncline() {
        return minIncline;
    }

    public static void setMinIncline(int minIncline) {
        MachineInfo.minIncline = minIncline;
    }

    public static int getMaxIncline() {
        return maxIncline;
    }

    public static void setMaxIncline(int maxIncline) {
        MachineInfo.maxIncline = maxIncline;
    }

    public static int getNegativeIncline() {
        return negativeIncline;
    }

    public static void setNegativeIncline(int negativeIncline) {
        MachineInfo.negativeIncline = negativeIncline;
    }

    public static int getWheelDiameter() {
        return wheelDiameter;
    }

    public static void setWheelDiameter(int wheelDiameter) {
        MachineInfo.wheelDiameter = wheelDiameter;
    }

    public static int getClientId() {
        return clientId;
    }

    public static void setClientId(int clientId) {
        MachineInfo.clientId = clientId;
    }

    public static int getWattGroup() {
        return wattGroup;
    }

    public static void setWattGroup(int wattGroup) {
        MachineInfo.wattGroup = wattGroup;
    }

    public static boolean hasIncline() {
        return hasIncline;
    }

    public static void setHasIncline(boolean hasIncline) {
        MachineInfo.hasIncline = hasIncline;
    }

    public static boolean hasFan() {
        return hasFan;
    }

    public static void setHasFan(boolean hasFan) {
        MachineInfo.hasFan = hasFan;
    }

    public static boolean hasFTMS() {
        return hasFTMS;
    }

    public static void setHasFTMS(boolean hasFTMS) {
        MachineInfo.hasFTMS = hasFTMS;
    }
}
