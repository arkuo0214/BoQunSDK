package com.boqun.serialportdemo.rower;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.boqun.iconsole.sdk.bike.BikeSportState;
import com.boqun.iconsole.sdk.bike.BoQunBike;
import com.boqun.iconsole.sdk.rower.BoQunRower;
import com.boqun.iconsole.sdk.rower.RowerConfigInfo;
import com.boqun.iconsole.sdk.rower.RowerKeyCode;
import com.boqun.iconsole.sdk.rower.RowerSportData;
import com.boqun.iconsole.sdk.rower.RowerWorkMode;
import com.boqun.iconsole.sdk.rower.impl.OnRowerListener;
import com.boqun.serialportdemo.BaseActivity;
import com.boqun.serialportdemo.R;
import com.boqun.serialportdemo.SystemEventReceiver;
import com.boqun.serialportdemo.Utils;

import java.util.Locale;


public class RowerActivity extends BaseActivity implements View.OnClickListener {

    private static final String TAG = RowerActivity.class.getSimpleName();

    private TextView mTvInitValue;
    private TextView mTvLoadValue;
    private TextView mTvInclineValue;
    private Button mBtFactory;
    private Button mBtFan;
    private TextView mTvSportValue;
    private TextView mTvPullAndPutState;
    private ProgressBar mPbPullAndPutProgress;
    private Button mBtLoadUp;
    private Button mBtStartAndPause;
    private Button mBtStop;
    private Button mBtLoadDown;
    private Button mBtEnableRead;
    private Button mBtDisableRead;


    private SystemEventReceiver mSystemEventReceiver;

    private boolean isSporting = false;

    private int currentLoadLevel;

    private int currentFanLevel;

    private AlertDialog mHintDialog;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rower_layout);

        initActionBar("Rower Machine", true);

        initViews();

        BoQunRower.init();

        BoQunRower.queryConfigInfo();

        BoQunRower.queryMachineInfo(BoQunRower.TYPE_LOAD_LEVEL);

        BoQunRower.queryMachineInfo(BoQunRower.TYPE_SPORT_STATUS);

        BoQunRower.setOnRowerListener(new OnRowerListener() {

            @Override
            public void onResponseConfigInfo(RowerConfigInfo info) {
                MachineInfo.setHasFan(info.hasFan());
                MachineInfo.setMinLoad(info.getMinLoadLevel());
                MachineInfo.setMaxLoad(info.getMaxLoadLevel());

                currentLoadLevel = info.getMinLoadLevel();

                mBtFan.setEnabled(MachineInfo.hasFan());

                String text = new StringBuilder()
                        .append("hasFan: ").append(info.hasFan()).append("\n")
                        .append("isLocalWatt: ").append(info.isLocalWattMode()).append("\n")
                        .append("minLoad: ").append(info.getMinLoadLevel()).append("\n")
                        .append("maxLoad: ").append(info.getMaxLoadLevel()).append("\n")
                        .append("minWatt: ").append(info.getMinWatt()).append("\n")
                        .append("maxWatt: ").append(info.getMaxWatt())
                        .toString();

                mTvInitValue.setText(text);
                mTvLoadValue.setText("LOAD:" + currentLoadLevel);
                mTvInclineValue.setText("INCLINE:" + currentLoadLevel);

                Log.d(TAG, "onResponseConfigInfo: " + info);
            }

            @Override
            public void onResponseSportStatus(int status) {
                Log.d(TAG, "onResponseSportStatus: " + status);
                isSporting = status == BikeSportState.START;
                if (status == BikeSportState.START) {
                    mBtFactory.setEnabled(false);
                    mBtStartAndPause.setText("Pause");
                    mTvLoadValue.setText("LOAD:" + currentLoadLevel);
                } else if (status == BikeSportState.PAUSE) {
                    mBtStartAndPause.setText("Start");
                    mBtFactory.setEnabled(false);
                    mTvLoadValue.setText("LOAD:" + MachineInfo.getMinLoad());
                } else if (status == BikeSportState.STOP) {
                    currentLoadLevel = MachineInfo.getMinLoad();
                    mTvLoadValue.setText("LOAD:" + currentLoadLevel);
                    mBtStartAndPause.setText("Start");
                    mTvSportValue.setText("");
                    mBtFactory.setEnabled(true);
                }
            }

            @Override
            public void onResponseSportData(RowerSportData data) {
                String text = new StringBuilder()
                        .append("Time Value: ").append(Utils.toTimeFormat(data.getTime())).append("\n")
                        .append("Spm Value: ").append(data.getSpm()).append("\n")
                        .append("Time/500 Value: ").append(Utils.toTimeFormat(data.getTimePer500m())).append("\n")
                        .append("Stroke Value: ").append(data.getStroke()).append("\n")
                        .append("HeartRate Value: ").append(data.getHeartRate()).append("\n")
                        .append("Distance Value: ").append(data.getDistance()).append("\n")
                        .append("Calories Value: ").append(data.getCalories()).append("\n")
                        .append("Watt Value: ").append(data.getWatt())
                        .toString();
                mTvSportValue.setText(text);

                Log.d(TAG, "onResponseSportData: " + data.toString());
            }

            @Override
            public void onResponsePullAndPut(int progress, boolean isPull) {
                mPbPullAndPutProgress.setProgress(progress);
                if (isPull) {
                    mTvPullAndPutState.setText("拉：");
                } else {
                    mTvPullAndPutState.setText("放：");
                }
            }

            @Override
            public void onResponseLoadLevel(int load) {
                currentLoadLevel = load;
                mTvLoadValue.setText("LOAD:" + currentLoadLevel);
            }

            @Override
            public void onResponseFanLevel(int level) {
                currentFanLevel = level;
                mBtFan.setText("FAN LEVEL:" + currentFanLevel);
            }

            @Override
            public void onExternalKeyEvent(int keyCode) {
                if (keyCode == RowerKeyCode.KEY_START_PAUSE) {
                    mBtStartAndPause.performClick();
                } else if (keyCode == RowerKeyCode.KEY_STOP) {
                    mBtStop.performClick();
                } else if (keyCode == RowerKeyCode.KEY_LOAD_UP) {
                    mBtLoadUp.performClick();
                } else if (keyCode == RowerKeyCode.KEY_LOAD_DOWN) {
                    mBtLoadDown.performClick();
                } else if (keyCode == RowerKeyCode.KEY_FAN) {
                    mBtFan.performClick();
                }
            }

            @Override
            public void onError(int errorCode) {
                if (mHintDialog == null && !isFinishing()) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                    builder.setTitle("Machine abnormal");
                    if (errorCode == 999) {
                        builder.setMessage("The machine parameters cannot be read. Please check whether the connection line is loose or whether the machine is matched with the lower control?");
                    } else if (errorCode == 998) {
                        builder.setMessage("Some parameters of the machine failed to read, it may not work properly!");
                    } else {
                        builder.setMessage("Happen \"" + String.format(Locale.getDefault(), "%02x", errorCode).toUpperCase() + "\" Error, please refer to the error code to see the cause of the error.");
                    }
                    builder.setCancelable(false);
                    builder.setPositiveButton("Understood", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            mHintDialog = null;
                        }
                    });
                    mHintDialog = builder.create();
                    mHintDialog.show();
                }
                Log.e(TAG, "onError: " + errorCode);
            }
        });

        mSystemEventReceiver = new SystemEventReceiver();
        mSystemEventReceiver.register(this, new SystemEventReceiver.Callback() {
            @Override
            public void onScreenOn() {
                Log.d(TAG, "onScreenOn");
                BoQunRower.setWorkMode(RowerWorkMode.NORMAL);
            }

            @Override
            public void onScreenOff() {
                Log.d(TAG, "onScreenOff");
                BoQunRower.setWorkMode(RowerWorkMode.SLEEP);
            }

            @Override
            public void onShutdown() {
                Log.d(TAG, "onShutdown");
                BoQunRower.setWorkMode(RowerWorkMode.SHUT_DOWN);
            }
        });
    }

    private void initViews() {

        mTvInitValue = findViewById(R.id.mTvInitValue);
        mTvLoadValue = findViewById(R.id.mTvLoadValue);
        mTvInclineValue = findViewById(R.id.mTvInclineValue);
        mBtFactory = findViewById(R.id.mBtFactory);
        mBtFan = findViewById(R.id.mBtFan);
        mTvSportValue = findViewById(R.id.mTvSportValue);
        mTvPullAndPutState = findViewById(R.id.mTvPullAndPutState);
        mPbPullAndPutProgress = findViewById(R.id.mPbPullAndPutProgress);
        mBtLoadUp = findViewById(R.id.mBtLoadUp);
        mBtStartAndPause = findViewById(R.id.mBtStartAndPause);
        mBtStop = findViewById(R.id.mBtStop);
        mBtLoadDown = findViewById(R.id.mBtLoadDown);
        mBtEnableRead = findViewById(R.id.mBtEnableRead);
        mBtDisableRead = findViewById(R.id.mBtDisableRead);

        mBtFactory.setOnClickListener(this);
        mBtFan.setOnClickListener(this);
        mBtLoadUp.setOnClickListener(this);
        mBtLoadDown.setOnClickListener(this);
        mBtStartAndPause.setOnClickListener(this);
        mBtStop.setOnClickListener(this);
        mBtEnableRead.setOnClickListener(this);
        mBtDisableRead.setOnClickListener(this);

    }


    @Override
    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.mBtFactory) {
            startActivity(new Intent(this, RowerFactoryActivity.class));
        } else if (id == R.id.mBtFan) {
            currentFanLevel = (currentFanLevel + 1) % 4;
            BoQunRower.setFanLevel(currentFanLevel);
        } else if (id == R.id.mBtLoadUp) {
            if (currentLoadLevel < MachineInfo.getMaxLoad()) {
                currentLoadLevel += 1;
                BoQunRower.setLoadLevel(currentLoadLevel);
            }
        } else if (id == R.id.mBtLoadDown) {
            if (currentLoadLevel > MachineInfo.getMinLoad()) {
                currentLoadLevel -= 1;
                BoQunRower.setLoadLevel(currentLoadLevel);
            }
        } else if (id == R.id.mBtStartAndPause) {
            if (!isSporting) {
                BoQunRower.start();
                BoQunRower.setLoadLevel(currentLoadLevel);
            } else {
                BoQunRower.pause();
            }
            isSporting = !isSporting;
        } else if (id == R.id.mBtStop) {
            BoQunRower.stop();
            isSporting = false;
        } else if (id == R.id.mBtEnableRead) {
            BoQunBike.setSerialPortEnabled(true);
        } else if (id == R.id.mBtDisableRead) {
            BoQunBike.setSerialPortEnabled(false);
        }
    }

    public Context getContext() {
        return this;
    }

    @Override
    protected void onDestroy() {

        BoQunRower.destroy();

        if (mHintDialog != null && mHintDialog.isShowing()) {
            mHintDialog.dismiss();
        }

        if (mSystemEventReceiver != null) {
            mSystemEventReceiver.unregister(this);
            mSystemEventReceiver = null;
        }
        super.onDestroy();
    }
}
