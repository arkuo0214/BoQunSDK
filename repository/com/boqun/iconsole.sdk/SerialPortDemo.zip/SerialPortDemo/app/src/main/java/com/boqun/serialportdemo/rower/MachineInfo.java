package com.boqun.serialportdemo.rower;

class MachineInfo {

    private static int minLoad = 1, maxLoad = 16;

    private static boolean hasFan = false;

    public static int getMinLoad() {
        return minLoad;
    }

    public static void setMinLoad(int minLoad) {
        MachineInfo.minLoad = minLoad;
    }

    public static int getMaxLoad() {
        return maxLoad;
    }

    public static void setMaxLoad(int maxLoad) {
        MachineInfo.maxLoad = maxLoad;
    }

    public static boolean hasFan() {
        return hasFan;
    }

    public static void setHasFan(boolean hasFan) {
        MachineInfo.hasFan = hasFan;
    }
}
