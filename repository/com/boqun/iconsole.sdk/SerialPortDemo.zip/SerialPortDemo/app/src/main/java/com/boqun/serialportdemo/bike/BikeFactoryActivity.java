package com.boqun.serialportdemo.bike;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;

import com.boqun.iconsole.sdk.bike.BoQunBikeFactory;
import com.boqun.iconsole.sdk.bike.impl.OnBikeFactoryListener;
import com.boqun.serialportdemo.BaseActivity;
import com.boqun.serialportdemo.R;


public class BikeFactoryActivity extends BaseActivity implements View.OnClickListener {

    private TextView mTvWheelDiameterValue;
    private Button mBtWheelDiameterUp;
    private Button mBtWheelDiameterDown;
    private Button mBtWheelDiameterSave;
    private TextView mTvMotorStrokeLoadValue;
    private Button mBtMotorStrokeLoadUp;
    private Button mBtMotorStrokeLoadDown;
    private TextView mTvMotorStrokeAdcValue;
    private Button mBtMotorStrokeAdcUp;
    private Button mBtMotorStrokeAdcDown;
    private Button mBtMotorStrokeSave;
    private TextView mTvInclineStrokeLoadValue;
    private Button mBtInclineStrokeLoadUp;
    private Button mBtInclineStrokeLoadDown;
    private TextView mTvInclineStrokeAdcValue;
    private Button mBtInclineStrokeAdcUp;
    private Button mBtInclineStrokeAdcDown;
    private Button mBtInclineStrokeSave;
    private Button mBtInclineStrokeAuto;

    private int wheelDiameter = MachineInfo.getWheelDiameter();

    private int motorStrokeLoadValue = MachineInfo.getMinLoad(), motorStrokeAdcValue = 0;

    private int inclineStrokeLoadValue = MachineInfo.getMinIncline(), inclineStrokeAdcValue = 0;

    private AlertDialog mInclineAutoCalDialog = null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bike_factory_layout);

        initActionBar("Bike Factory", true);

        initViews();

        mTvWheelDiameterValue.setText(String.valueOf(wheelDiameter));

        BoQunBikeFactory.init();

        BoQunBikeFactory.queryLoadMotorStroke(MachineInfo.getMinLoad());

        if (MachineInfo.hasIncline()) {
            BoQunBikeFactory.queryInclineMotorStroke(MachineInfo.getMinIncline());
        }

        BoQunBikeFactory.setOnBikeFactoryListener(new OnBikeFactoryListener() {

            @Override
            public void onResponseLoadMotorStoke(int load, int adc) {
                motorStrokeLoadValue = load;
                motorStrokeAdcValue = adc;
                mTvMotorStrokeLoadValue.setText("LOAD:" + load);
                mTvMotorStrokeAdcValue.setText("ADC:" + adc);
            }

            @Override
            public void onResponseInclineMotorStroke(int incline, int adc) {
                inclineStrokeLoadValue = incline;
                inclineStrokeAdcValue = adc;
                mTvInclineStrokeLoadValue.setText("INCLINE:" + incline);
                mTvInclineStrokeAdcValue.setText("ADC:" + adc);
            }

            @Override
            public void onResponseInclineAutoCorrection(int state, int adc) {
                if (mInclineAutoCalDialog.isShowing()) {
                    TextView tv = mInclineAutoCalDialog.findViewById(R.id.mTvMsg);
                    if (tv != null) {
                        tv.setText("INCLINE: " + state + " ，INCLINE ADC: " + adc);
                    }
                }
                Log.d("TAG", "onResponseInclineAutoCal: " + state + " value");
            }
        });

    }

    private void initViews() {

        mTvWheelDiameterValue = findViewById(R.id.mTvWheelDiameterValue);
        mBtWheelDiameterUp = findViewById(R.id.mBtWheelDiameterUp);
        mBtWheelDiameterDown = findViewById(R.id.mBtWheelDiameterDown);
        mBtWheelDiameterSave = findViewById(R.id.mBtWheelDiameterSave);
        mTvMotorStrokeLoadValue = findViewById(R.id.mTvMotorStrokeLoadValue);
        mBtMotorStrokeLoadUp = findViewById(R.id.mBtMotorStrokeLoadUp);
        mBtMotorStrokeLoadDown = findViewById(R.id.mBtMotorStrokeLoadDown);
        mTvMotorStrokeAdcValue = findViewById(R.id.mTvMotorStrokeAdcValue);
        mBtMotorStrokeAdcUp = findViewById(R.id.mBtMotorStrokeAdcUp);
        mBtMotorStrokeAdcDown = findViewById(R.id.mBtMotorStrokeAdcDown);
        mBtMotorStrokeSave = findViewById(R.id.mBtMotorStrokeSave);
        mTvInclineStrokeLoadValue = findViewById(R.id.mTvInclineStrokeLoadValue);
        mBtInclineStrokeLoadUp = findViewById(R.id.mBtInclineStrokeLoadUp);
        mBtInclineStrokeLoadDown = findViewById(R.id.mBtInclineStrokeLoadDown);
        mTvInclineStrokeAdcValue = findViewById(R.id.mTvInclineStrokeAdcValue);
        mBtInclineStrokeAdcUp = findViewById(R.id.mBtInclineStrokeAdcUp);
        mBtInclineStrokeAdcDown = findViewById(R.id.mBtInclineStrokeAdcDown);
        mBtInclineStrokeSave = findViewById(R.id.mBtInclineStrokeSave);
        mBtInclineStrokeAuto = findViewById(R.id.mBtInclineStrokeAuto);

        mBtWheelDiameterUp.setOnClickListener(this);
        mBtWheelDiameterDown.setOnClickListener(this);
        mBtWheelDiameterSave.setOnClickListener(this);
        mBtMotorStrokeLoadUp.setOnClickListener(this);
        mBtMotorStrokeLoadDown.setOnClickListener(this);
        mBtMotorStrokeAdcUp.setOnClickListener(this);
        mBtMotorStrokeAdcDown.setOnClickListener(this);
        mBtMotorStrokeSave.setOnClickListener(this);
        mBtInclineStrokeLoadUp.setOnClickListener(this);
        mBtInclineStrokeLoadDown.setOnClickListener(this);
        mBtInclineStrokeAdcUp.setOnClickListener(this);
        mBtInclineStrokeAdcDown.setOnClickListener(this);
        mBtInclineStrokeSave.setOnClickListener(this);
        mBtInclineStrokeAuto.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.mBtWheelDiameterUp) {
            wheelDiameter++;
            mTvWheelDiameterValue.setText(String.valueOf(wheelDiameter));
        } else if (id == R.id.mBtWheelDiameterDown) {
            wheelDiameter = wheelDiameter > 0 ? wheelDiameter - 1 : 0;
            mTvWheelDiameterValue.setText(String.valueOf(wheelDiameter));
        } else if (id == R.id.mBtWheelDiameterSave) {
            BoQunBikeFactory.setWheelDiameter(wheelDiameter);
        } else if (id == R.id.mBtMotorStrokeLoadUp) {
            if (motorStrokeLoadValue < MachineInfo.getMaxLoad()) {
                motorStrokeLoadValue++;
                BoQunBikeFactory.queryLoadMotorStroke(motorStrokeLoadValue);
            }
        } else if (id == R.id.mBtMotorStrokeLoadDown) {
            if (motorStrokeLoadValue > MachineInfo.getMinLoad()) {
                motorStrokeLoadValue--;
                BoQunBikeFactory.queryLoadMotorStroke(motorStrokeLoadValue);
            }
        } else if (id == R.id.mBtMotorStrokeAdcUp) {
            motorStrokeAdcValue++;
            mTvMotorStrokeAdcValue.setText("ADC:" + motorStrokeAdcValue);
        } else if (id == R.id.mBtMotorStrokeAdcDown) {
            motorStrokeAdcValue = motorStrokeAdcValue > 0 ? motorStrokeAdcValue - 1 : 0;
            mTvMotorStrokeAdcValue.setText("ADC:" + motorStrokeAdcValue);
        } else if (id == R.id.mBtMotorStrokeSave) {
            BoQunBikeFactory.setLoadMotorStroke(motorStrokeLoadValue, motorStrokeAdcValue);
        } else if (id == R.id.mBtInclineStrokeLoadUp) {
            if (inclineStrokeLoadValue < MachineInfo.getMaxIncline()) {
                inclineStrokeLoadValue++;
                BoQunBikeFactory.queryInclineMotorStroke(inclineStrokeLoadValue);
            }
        } else if (id == R.id.mBtInclineStrokeLoadDown) {
            if (inclineStrokeLoadValue > MachineInfo.getMinIncline()) {
                inclineStrokeLoadValue--;
                BoQunBikeFactory.queryInclineMotorStroke(inclineStrokeLoadValue);
            }
        } else if (id == R.id.mBtInclineStrokeAdcUp) {
            inclineStrokeAdcValue++;
            mTvInclineStrokeAdcValue.setText("ADC:" + inclineStrokeAdcValue);
        } else if (id == R.id.mBtInclineStrokeAdcDown) {
            inclineStrokeAdcValue = inclineStrokeAdcValue > 0 ? inclineStrokeAdcValue - 1 : 0;
            mTvInclineStrokeAdcValue.setText("ADC:" + inclineStrokeAdcValue);
        } else if (id == R.id.mBtInclineStrokeSave) {
            BoQunBikeFactory.setInclineMotorStroke(inclineStrokeLoadValue, inclineStrokeAdcValue);
        } else if (id == R.id.mBtInclineStrokeAuto) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Incline Automatic calibration");
            builder.setView(R.layout.msg_text_layout);
            builder.setCancelable(false);
            builder.setPositiveButton("Start", null);
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    BoQunBikeFactory.stopInclineAutoCorrection();
                }
            });
            mInclineAutoCalDialog = builder.create();
            mInclineAutoCalDialog.show();
            mInclineAutoCalDialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String text = mInclineAutoCalDialog.getButton(DialogInterface.BUTTON_POSITIVE).getText().toString();
                    if ("Start".equals(text)) {
                        BoQunBikeFactory.startInclineAutoCorrection();
                        mInclineAutoCalDialog.getButton(DialogInterface.BUTTON_POSITIVE).setText("Stop");
                    } else {
                        BoQunBikeFactory.stopInclineAutoCorrection();
                        mInclineAutoCalDialog.getButton(DialogInterface.BUTTON_POSITIVE).setText("Start");
                    }
                }
            });
        }

    }

    @Override
    protected void onDestroy() {
        BoQunBikeFactory.destroy();
        super.onDestroy();
    }
}
