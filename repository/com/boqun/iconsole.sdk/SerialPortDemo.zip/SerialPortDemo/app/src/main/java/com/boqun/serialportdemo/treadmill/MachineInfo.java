package com.boqun.serialportdemo.treadmill;

class MachineInfo {

    private static int minSpeed = 10, maxSpeed = 200, clipSpeed = 10;

    private static int minIncline = 0, maxIncline = 20;

    private static int clientId = 0;

    private static int wattGroup = 0;

    private static boolean hasIncline = false;

    private static boolean hasFan = false;


    public static int getMinSpeed() {
        return minSpeed;
    }

    public static void setMinSpeed(int minSpeed) {
        MachineInfo.minSpeed = minSpeed;
    }

    public static int getMaxSpeed() {
        return maxSpeed;
    }

    public static void setMaxSpeed(int maxSpeed) {
        MachineInfo.maxSpeed = maxSpeed;
    }

    public static int getClipSpeed() {
        return clipSpeed;
    }

    public static void setClipSpeed(int clipSpeed) {
        MachineInfo.clipSpeed = clipSpeed;
    }

    public static int getMinIncline() {
        return minIncline;
    }

    public static void setMinIncline(int minIncline) {
        MachineInfo.minIncline = minIncline;
    }

    public static int getMaxIncline() {
        return maxIncline;
    }

    public static void setMaxIncline(int maxIncline) {
        MachineInfo.maxIncline = maxIncline;
    }

    public static int getClientId() {
        return clientId;
    }

    public static void setClientId(int clientId) {
        MachineInfo.clientId = clientId;
    }

    public static int getWattGroup() {
        return wattGroup;
    }

    public static void setWattGroup(int wattGroup) {
        MachineInfo.wattGroup = wattGroup;
    }

    public static boolean hasIncline() {
        return hasIncline;
    }

    public static void setHasIncline(boolean hasIncline) {
        MachineInfo.hasIncline = hasIncline;
    }

    public static boolean hasFan() {
        return hasFan;
    }

    public static void setHasFan(boolean hasFan) {
        MachineInfo.hasFan = hasFan;
    }
}
