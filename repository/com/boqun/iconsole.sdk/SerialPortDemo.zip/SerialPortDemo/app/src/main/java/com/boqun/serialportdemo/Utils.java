package com.boqun.serialportdemo;

import java.util.Locale;

/**
 * @Description TODO
 * @Author Felix
 * @Date 2021/11/17 14:17
 */
public class Utils {

    public static String toTimeFormat(long sec) {
        if (sec < 1) {
            return "00:00";
        }
        long hours = sec / 3600;

        long rem = sec % 3600;
        long minutes = rem / 60;
        long seconds = rem % 60;
        if (hours <= 0) {
            return String.format(Locale.getDefault(),"%02d:%02d", minutes, seconds);
        }
        return String.format(Locale.getDefault(),"%02d:%02d:%02d", hours, minutes, seconds);
    }

}
