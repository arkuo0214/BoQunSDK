package com.boqun.serialportdemo.treadmill;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.boqun.iconsole.sdk.ErrorCode;
import com.boqun.iconsole.sdk.bike.BoQunBike;
import com.boqun.iconsole.sdk.treadmill.BoQunTreadmill;
import com.boqun.iconsole.sdk.treadmill.CoolDownState;
import com.boqun.iconsole.sdk.treadmill.TreadmillConfigInfo;
import com.boqun.iconsole.sdk.treadmill.TreadmillKeyCode;
import com.boqun.iconsole.sdk.treadmill.TreadmillSportState;
import com.boqun.iconsole.sdk.treadmill.TreadmillStatusCallbacks;
import com.boqun.iconsole.sdk.treadmill.TreadmillWorkMode;
import com.boqun.iconsole.sdk.treadmill.impl.OnTreadmillListener;
import com.boqun.serialportdemo.BaseActivity;
import com.boqun.serialportdemo.R;
import com.boqun.serialportdemo.SystemEventReceiver;

import java.util.Locale;

public class TreadmillActivity extends BaseActivity implements View.OnClickListener {

    private static final String TAG = TreadmillActivity.class.getSimpleName();

    private TextView mTvInitValue;
    private TextView mTvSpeedValue;
    private TextView mTvInclineValue;
    private Button mBtFactory;
    private Button mBtFan;
    private TextView mTvSportValue;
    private Button mBtSpeedUp;
    private Button mBtSpeedDown;
    private Button mBtStartAndPause;
    private Button mBtStop;
    private Button mBtInclineUp;
    private Button mBtInclineDown;
    private Button mBtCoolDown;
    private Button mBtEnableRead;
    private Button mBtDisableRead;

    private SystemEventReceiver mSystemEventReceiver;

    private int currentFanLevel = 0;
    private int currentSpeed = 0, currentIncline = 0;
    private boolean mSecurityLeyFallsOff = false;

    private AlertDialog mHintDialog = null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.treadmill_layout);

        initActionBar("Treadmill", true);

        mTvInitValue = findViewById(R.id.mTvInitValue);
        mTvSpeedValue = findViewById(R.id.mTvSpeedValue);
        mTvInclineValue = findViewById(R.id.mTvInclineValue);
        mBtFactory = findViewById(R.id.mBtFactory);
        mBtFan = findViewById(R.id.mBtFan);
        mTvSportValue = findViewById(R.id.mTvSportValue);
        mBtSpeedUp = findViewById(R.id.mBtSpeedUp);
        mBtSpeedDown = findViewById(R.id.mBtSpeedDown);
        mBtStartAndPause = findViewById(R.id.mBtStartAndPause);
        mBtStop = findViewById(R.id.mBtStop);
        mBtInclineUp = findViewById(R.id.mBtInclineUp);
        mBtInclineDown = findViewById(R.id.mBtInclineDown);
        mBtCoolDown = findViewById(R.id.mBtCoolDown);
        mBtEnableRead = findViewById(R.id.mBtEnableRead);
        mBtDisableRead = findViewById(R.id.mBtDisableRead);

        mBtStartAndPause.setOnClickListener(this);
        mBtStop.setOnClickListener(this);
        mBtSpeedUp.setOnClickListener(this);
        mBtSpeedDown.setOnClickListener(this);
        mBtInclineUp.setOnClickListener(this);
        mBtInclineDown.setOnClickListener(this);
        mBtFactory.setOnClickListener(this);
        mBtFan.setOnClickListener(this);
        mBtCoolDown.setOnClickListener(this);
        mBtEnableRead.setOnClickListener(this);
        mBtDisableRead.setOnClickListener(this);


        BoQunTreadmill.init(new OnTreadmillListener() {

            @Override
            public void onResponseConfigInfo(TreadmillConfigInfo info) {

                MachineInfo.setWattGroup(info.getWattGroup());
                MachineInfo.setMinSpeed(info.getMinSpeedLevel());
                MachineInfo.setMaxSpeed(info.getMaxSpeedLevel());
                MachineInfo.setClipSpeed(info.getChipSpeedLevel());
                MachineInfo.setMinIncline(info.getMinInclineLevel());
                MachineInfo.setMaxIncline(info.getMaxInclineLevel());
                MachineInfo.setHasIncline(info.hanIncline());
                MachineInfo.setHasFan(info.hasFan());

                currentSpeed = MachineInfo.getMinSpeed();
                currentIncline = MachineInfo.getMinIncline();

                mBtFan.setEnabled(MachineInfo.hasFan());
                mBtInclineUp.setEnabled(MachineInfo.hasIncline());
                mBtInclineDown.setEnabled(MachineInfo.hasIncline());

                String text = new StringBuilder()
                        .append("\r\n").append("Watt Group： ").append(MachineInfo.getWattGroup())
                        .append("\r\n").append("Min Speed： ").append(MachineInfo.getMinSpeed())
                        .append("\r\n").append("Max Speed： ").append(MachineInfo.getMaxSpeed())
                        .append("\r\n").append("Chip Speed： ").append(MachineInfo.getClipSpeed())
                        .append("\r\n").append("Min Incline： ").append(MachineInfo.getMinIncline())
                        .append("\r\n").append("Max Incline： ").append(MachineInfo.getMaxIncline())
                        .append("\r\n").append("Has Fan： ").append((MachineInfo.hasFan() ? "Yes" : "No"))
                        .append("\r\n").append("Has Incline： ").append((MachineInfo.hasIncline() ? "Yes" : "No"))
                        .toString();

                mTvInitValue.setText(text);
                mTvSpeedValue.setText("SPEED:" + currentSpeed);
                mTvInclineValue.setText("INCLINE:" + currentIncline);

                Log.d(TAG, "onResponseConfigInfo: " + info.toString());
            }

            @Override
            public void onResponseSportStatus(int state) {
                isSporting = state == TreadmillSportState.START;
                if (state == TreadmillSportState.START) {
                    mBtStartAndPause.setText("Pause");
                    mBtFactory.setEnabled(false);
                } else if (state == TreadmillSportState.PAUSE) {
                    mBtStartAndPause.setText("Start");
                    mBtFactory.setEnabled(false);
                } else if (state == TreadmillSportState.STOP || state == TreadmillSportState.ERROR) {
                    mBtStartAndPause.setText("Start");
                    mTvSportValue.setText("");
                    mBtFactory.setEnabled(true);

                    onResponseSpeedLevel(MachineInfo.getMinSpeed());
                }
            }

            @Override
            public void onResponseSportData(int state, int heartRate, int speed) {
                String text = new StringBuilder()
                        .append("\r\n").append("PULSE Value： ").append(heartRate)
                        .append("\r\n").append("Speed Value： ").append(speed)
                        .toString();
                mTvSportValue.setText(text);
            }

            @Override
            public void onResponseSpeedLevel(int speed) {
                currentSpeed = speed;
                mTvSpeedValue.setText("SPEED:" + String.format(Locale.getDefault(), "%.1f", (currentSpeed / 10f)));
            }

            @Override
            public void onResponseInclineLevel(int incline) {
                currentIncline = incline;
                mTvInclineValue.setText("INCLINE:" + currentIncline);
            }

            @Override
            public void onResponseFanLevel(int level) {
                currentFanLevel = level;
                mBtFan.setText("FAN LEVEL:" + currentFanLevel);
            }


            @Override
            public void onExternalKeyEvent(int keyCode, int value) {
                if (keyCode == TreadmillKeyCode.KEY_START_PAUSE) {
                    mBtStartAndPause.performClick();
                } else if (keyCode == TreadmillKeyCode.KEY_STOP) {
                    mBtStop.performClick();
                } else if (keyCode == TreadmillKeyCode.KEY_SPEED_UP) {
                    mBtSpeedUp.performClick();
                } else if (keyCode == TreadmillKeyCode.KEY_SPEED_DOWN) {
                    mBtSpeedDown.performClick();
                } else if (keyCode == TreadmillKeyCode.KEY_INCLINE_UP) {
                    mBtInclineUp.performClick();
                } else if (keyCode == TreadmillKeyCode.KEY_INCLINE_DOWN) {
                    mBtInclineDown.performClick();
                } else if (keyCode == TreadmillKeyCode.KEY_FAST_SPEED) {
                    BoQunTreadmill.setSpeedLevel(value);
                } else if (keyCode == TreadmillKeyCode.KEY_FAST_INCLINE) {
                    BoQunTreadmill.setInclineLevel(value);
                } else if (keyCode == TreadmillKeyCode.KEY_COOL_DOWN) {
                    BoQunTreadmill.coolDown();
                }
                Log.d(TAG, "onExternalKeyEvent: " + keyCode);
            }

            @Override
            public void onError(int errorCode) {
                if (mHintDialog == null && !isFinishing()) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                    builder.setTitle("Machine abnormal");
                    if (errorCode == ErrorCode.NO_RESPONSE) {
                        builder.setMessage("The machine parameters cannot be read. Please check whether the connection line is loose or whether the machine is matched with the lower control?");
                    } else if (errorCode == ErrorCode.CONFIG_EXCEPTION) {
                        builder.setMessage("Some parameters of the machine failed to read, it may not work properly!");
                    } else if (errorCode == ErrorCode.SERIAL_OPEN_FAILED) {
                        builder.setMessage("The device cannot use serial port for communication!");
                    } else {
                        builder.setMessage("Happen \"" + String.format(Locale.getDefault(), "%02x", errorCode).toUpperCase() + "\" Error, please refer to the error code to see the cause of the error.");
                    }
                    builder.setCancelable(false);
                    builder.setPositiveButton("Understood", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            mHintDialog = null;
                        }
                    });
                    mHintDialog = builder.create();
                    mHintDialog.show();
                }
                Log.e(TAG, "onError: " + errorCode);
            }
        });

        BoQunTreadmill.queryConfigInfo();

        BoQunTreadmill.queryMachineInfo(BoQunTreadmill.TYPE_SPORT_STATUS);

        BoQunTreadmill.queryMachineInfo(BoQunTreadmill.TYPE_SPEED_AND_INCLINE);


        BoQunTreadmill.registerStateListener(new TreadmillStatusCallbacks.SafetyKeyStatusCallback() {
            @Override
            public void onSafetyKeyStatus(boolean normal) {
                if (mHintDialog == null && !isFinishing()) {
                    BoQunTreadmill.stop();

                    AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                    builder.setTitle("Protection mechanism trigger");
                    builder.setMessage("When you see this message, please check if the safety lock is placed properly!");
                    builder.setCancelable(false);
                    mHintDialog = builder.create();
                    mHintDialog.show();
                } else if (mHintDialog != null && normal) {
                    if (mHintDialog.isShowing()) {
                        mHintDialog.dismiss();
                        mHintDialog = null;
                    }
                }
            }
        });

        BoQunTreadmill.registerStateListener(new TreadmillStatusCallbacks.CoolDownStatusCallback() {
            @Override
            public void onCoolDownStatus(int status, int speed) {
                Log.e(TAG, "onCoolDownStateChange: " + status + " speed：" + speed);
                if (mHintDialog == null && !isFinishing() && status == CoolDownState.START) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                    builder.setTitle("Cool Down");
                    builder.setMessage("Cool Down mode activated, slowing down...");
                    builder.setCancelable(false);
                    mHintDialog = builder.create();
                    mHintDialog.show();
                } else if (status == CoolDownState.END) {
                    if (mHintDialog != null && mHintDialog.isShowing()) {
                        mHintDialog.dismiss();
                        mHintDialog = null;

                        BoQunTreadmill.stop();
                    }
                }
            }
        });

        mSystemEventReceiver = new SystemEventReceiver();
        mSystemEventReceiver.register(this, new SystemEventReceiver.Callback() {
            @Override
            public void onScreenOn() {
                Log.e(TAG, "onScreenOn");
                BoQunTreadmill.setWorkMode(TreadmillWorkMode.NORMAL);
            }

            @Override
            public void onScreenOff() {
                Log.e(TAG, "onScreenOff");
                BoQunTreadmill.setWorkMode(TreadmillWorkMode.SLEEP);
            }

            @Override
            public void onShutdown() {
                Log.e(TAG, "onShutdown");
                BoQunTreadmill.setWorkMode(TreadmillWorkMode.SHUT_DOWN);
            }
        });
    }

    private boolean isSporting = false;

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.mBtStartAndPause) {
            if (!isSporting) {
                BoQunTreadmill.start();
                BoQunTreadmill.setSpeedLevel(MachineInfo.getMinSpeed());
                if (MachineInfo.hasIncline()) {
                    BoQunTreadmill.setInclineLevel(currentIncline);
                }
            } else {
                BoQunTreadmill.pause();
            }
            isSporting = !isSporting;
        } else if (id == R.id.mBtStop) {
            BoQunTreadmill.stop();
            isSporting = false;
        } else if (id == R.id.mBtSpeedUp) {
            if (currentSpeed < MachineInfo.getMaxSpeed()) {
                currentSpeed += MachineInfo.getClipSpeed();
                BoQunTreadmill.setSpeedLevel(currentSpeed);
            }
        } else if (id == R.id.mBtSpeedDown) {
            if (currentSpeed > MachineInfo.getMinSpeed()) {
                currentSpeed -= MachineInfo.getClipSpeed();
                BoQunTreadmill.setSpeedLevel(currentSpeed);
            }
        } else if (id == R.id.mBtInclineUp) {
            if (currentIncline < MachineInfo.getMaxIncline()) {
                currentIncline += 1;
                BoQunTreadmill.setInclineLevel(currentIncline);
            }
        } else if (id == R.id.mBtInclineDown) {
            if (currentIncline > MachineInfo.getMinIncline()) {
                currentIncline -= 1;
                BoQunTreadmill.setInclineLevel(currentIncline);
            }
        } else if (id == R.id.mBtFan) {
            currentFanLevel = (currentFanLevel + 1) % 4;
            BoQunTreadmill.setFanLevel(currentFanLevel);
        } else if (id == R.id.mBtFactory) {
            startActivity(new Intent(this, TreadmillFactoryActivity.class));
        } else if (id == R.id.mBtCoolDown) {
            BoQunTreadmill.coolDown();
        } else if (id == R.id.mBtEnableRead) {
            BoQunBike.setSerialPortEnabled(true);
        } else if (id == R.id.mBtDisableRead) {
            BoQunBike.setSerialPortEnabled(false);
        }

    }

    public Context getContext() {
        return this;
    }

    @Override
    protected void onDestroy() {

        BoQunTreadmill.unregisterAllStateListener();
        BoQunTreadmill.destroy();

        if (mHintDialog != null && mHintDialog.isShowing()) {
            mHintDialog.dismiss();
        }

        if (mSystemEventReceiver != null) {
            mSystemEventReceiver.unregister(this);
            mSystemEventReceiver = null;
        }
        super.onDestroy();
    }
}
