package com.boqun.mobisdkdemo;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.boqun.mobisdk.uart.MoBiDevice;
import com.boqun.mobisdk.uart.OnDeviceDataCallback;
import com.boqun.mobisdk.uart.databean.DeviceDataBean;
import com.boqun.mobisdk.uart.databean.ErrorCodeBean;
import com.boqun.mobisdk.uart.databean.InitDataBean;
import com.boqun.mobisdk.uart.databean.MachineStatusBeen;
import com.boqun.mobisdk.uart.databean.ResistanceDataBean;
import com.boqun.mobisdk.uart.databean.SignalTimeDataBean;
import com.boqun.mobisdk.uart.databean.TreadmillSportDataBean;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static final int SEND_TV_MANUFACTURER_NAME = 0;
    private static final int SEND_TV_MODEL_NUMBER = 1;
    private static final int SEND_TV_HARDWARE_REVISION = 2;
    private static final int SEND_TV_FIRMWARE_REVISION = 3;
    private static final int SEND_TV_DATA_REPORTING_METHOD = 4;
    private static final int SEND_TV_DEVICE_TYPE = 5;
    private static final int SEND_TV_DEVICE_SUBTYPE = 6;
    private static final int SEND_TV_DEVICE_CONTROL_TYPE = 7;
    private static final int SEND_TV_SENSOR_SIGNAL_SCALE = 8;
    private static final int SEND_TV_NUMBER_OF_MAGNETS = 9;
    private static final int SEND_TV_BATTERY = 10;
    private static final int SEND_TV_RESISTANCE_MAX = 11;
    private static final int SEND_TV_RESISTANCE_MIN = 12;
    private static final int SEND_TV_RESISTANCE_MODE = 13;
    private static final int SEND_TV_SPEED_RANGE = 14;
    private static final int SEND_TV_INCLINE_RANGE = 15;
    private static final int SEND_TV_MACHINE_STATUS = 16;
    private static final int SEND_TV_MACHINE_ENTER_STATE_METHOD = 17;
    private static final int SEND_TV_ERROR_CODE = 18;
    private static final int SEND_TV_RESISTANCE = 19;
    private static final int SEND_TV_SIGNAL_TIME_INTERVAL = 20;
    private static final int SEND_TV_SIGNAL_COUNT = 21;
    private static final int SEND_TV_SPEED = 22;
    private static final int SEND_TV_INCLINE = 23;
    private static final int SEND_TV_STEP = 24;
    private static final int SEND_TV_TIME = 25;
    private static final int SEND_TV_DISTANCE = 26;
    private static final int SEND_TV_CALORIES = 27;
    private static final int SEND_TV_HEARTBEAT = 28;

    private static final String TAG = MainActivity.class.getSimpleName();
    private Context mContext = null;

    private TextView mTvManufacturerName;
    private TextView mTvHardwareRevision;
    private TextView mTvModelNumber;
    private TextView mTvFirmwareRevision;
    private TextView mTvDataReportingMethod;
    private TextView mTvDeviceType;
    private TextView mTvDeviceSubType;
    private TextView mTvDeviceControlType;
    private TextView mTvSensorSignalScale;
    private TextView mTvNumberOfMagnets;
    private TextView mTvBattery;
    private TextView mTvResistanceMax;
    private TextView mTvResistanceMin;
    private TextView mTvResistanceMode;
    private TextView mTvSpeedRange;
    private TextView mTvInclineRange;
    private TextView mTvMachineStatus;
    private TextView mTvMachineEnterStateMethod;
    private TextView mTvErrorCode;
    private TextView mTvResistance;
    private TextView mTvSignalTimeInterval;
    private TextView mTvSignalCount;
    private TextView mTvSpeed;
    private TextView mTvIncline;
    private TextView mTvStep;
    private TextView mTvTime;
    private TextView mTvDistance;
    private TextView mTvCalories;
    private TextView mTvHeartbeat;
    private EditText mEtSetSpeed;
    private Button mBtSetSpeed;
    private EditText mEtSetIncline;
    private Button mBtSetIncline;
    private EditText mEtSetResistance;
    private Button mBtSetResistance;
    private Button mBtStop;
    private Button mBtStart;
    private Button mBtPause;

    private String manufacturerName = "";
    private String modelNumber = "";
    private String hardwareRevision = "";
    private String firmwareRevision = "";

    private int dataReportingMethod = 0;
    private int deviceType = 0;
    private int deviceSubType = 0;
    private int deviceControlType = 0;
    private int sensorSignalScale = 0;
    private int numberOfMagnets = 0;
    private int battery = 0;
    private int resistanceMax = 0;
    private int resistanceMin = 0;
    private int resistanceMode = 0;
    private int[] speedRange = {0, 0};
    private int[] inclineRange = {0, 0};

    private int status = 0;
    private int machineEnterStateMethod = 0;
    private int errorCodeHi = 0;
    private int errorCodeLow = 0;
    private int resistance = 0;

    private int signalTimeInterval = 0;
    private int signalCount = 0;

    private int speed = 0;
    private int incline = 0;
    private int step = 0;
    private int time = 0;
    private int distance = 0;
    private int calories = 0;
    private int pulse = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContext = this;

        mTvManufacturerName = findViewById(R.id.mTvManufacturerName);
        mTvHardwareRevision = findViewById(R.id.mTvHardwareRevision);
        mTvModelNumber = findViewById(R.id.mTvModelNumber);
        mTvFirmwareRevision = findViewById(R.id.mTvFirmwareRevision);
        mTvDataReportingMethod = findViewById(R.id.mTvDataReportingMethod);
        mTvDeviceType = findViewById(R.id.mTvDeviceType);
        mTvDeviceSubType = findViewById(R.id.mTvDeviceSubType);
        mTvDeviceControlType = findViewById(R.id.mTvDeviceControlType);
        mTvSensorSignalScale = findViewById(R.id.mTvSensorSignalScale);
        mTvNumberOfMagnets = findViewById(R.id.mTvNumberOfMagnets);
        mTvBattery = findViewById(R.id.mTvBattery);
        mTvResistanceMax = findViewById(R.id.mTvResistanceMax);
        mTvResistanceMin = findViewById(R.id.mTvResistanceMin);
        mTvResistanceMode = findViewById(R.id.mTvResistanceMode);
        mTvSpeedRange = findViewById(R.id.mTvSpeedRange);
        mTvInclineRange = findViewById(R.id.mTvInclineRange);
        mTvMachineStatus = findViewById(R.id.mTvMachineStatus);
        mTvMachineEnterStateMethod = findViewById(R.id.mTvMachineEnterStateMethod);
        mTvErrorCode = findViewById(R.id.mTvErrorCode);
        mTvResistance = findViewById(R.id.mTvResistance);
        mTvSignalTimeInterval = findViewById(R.id.mTvSignalTimeInterval);
        mTvSignalCount = findViewById(R.id.mTvSignalCount);
        mTvSpeed = findViewById(R.id.mTvSpeed);
        mTvIncline = findViewById(R.id.mTvIncline);
        mTvStep = findViewById(R.id.mTvStep);
        mTvTime = findViewById(R.id.mTvTime);
        mTvDistance = findViewById(R.id.mTvDistance);
        mTvCalories = findViewById(R.id.mTvCalories);
        mTvHeartbeat = findViewById(R.id.mTvHeartbeat);
        mEtSetSpeed = findViewById(R.id.mEtSetSpeed);
        mBtSetSpeed = findViewById(R.id.mBtSetSpeed);
        mEtSetIncline = findViewById(R.id.mEtSetIncline);
        mBtSetIncline = findViewById(R.id.mBtSetIncline);
        mEtSetResistance = findViewById(R.id.mEtSetResistance);
        mBtSetResistance = findViewById(R.id.mBtSetResistance);
        mBtStop = findViewById(R.id.mBtStop);
        mBtStart = findViewById(R.id.mBtStart);
        mBtPause = findViewById(R.id.mBtPause);

        mBtSetSpeed.setOnClickListener(this);
        mBtSetIncline.setOnClickListener(this);
        mBtSetResistance.setOnClickListener(this);
        mBtStop.setOnClickListener(this);
        mBtStart.setOnClickListener(this);
        mBtPause.setOnClickListener(this);

        try {
            MoBiDevice.init(mContext, new OnDeviceDataCallback() {
                @Override
                public void onInitData(InitDataBean initData) {
                    manufacturerName = initData.getManufacturerName();
                    handler.sendEmptyMessage(SEND_TV_MANUFACTURER_NAME);
                    modelNumber = initData.getModelNumber();
                    handler.sendEmptyMessage(SEND_TV_MODEL_NUMBER);
                    hardwareRevision = initData.getHardwareRevision();
                    handler.sendEmptyMessage(SEND_TV_HARDWARE_REVISION);
                    firmwareRevision = initData.getFirmwareRevision();
                    handler.sendEmptyMessage(SEND_TV_FIRMWARE_REVISION);
                }

                @Override
                public void onDeviceData(DeviceDataBean deviceData) {
                    dataReportingMethod = deviceData.getDataReportingMethod();
                    handler.sendEmptyMessage(SEND_TV_DATA_REPORTING_METHOD);
                    deviceType = deviceData.getDeviceType();
                    handler.sendEmptyMessage(SEND_TV_DEVICE_TYPE);
                    deviceSubType = deviceData.getDeviceSubType();
                    handler.sendEmptyMessage(SEND_TV_DEVICE_SUBTYPE);
                    deviceControlType = deviceData.getDeviceControlType();
                    handler.sendEmptyMessage(SEND_TV_DEVICE_CONTROL_TYPE);
                    sensorSignalScale = deviceData.getSensorSignalScale();
                    handler.sendEmptyMessage(SEND_TV_SENSOR_SIGNAL_SCALE);
                    numberOfMagnets = deviceData.getNumberOfMagnets();
                    handler.sendEmptyMessage(SEND_TV_NUMBER_OF_MAGNETS);
                    battery = deviceData.getBattery();
                    handler.sendEmptyMessage(SEND_TV_BATTERY);
                    resistanceMax = deviceData.getResistanceMax();
                    handler.sendEmptyMessage(SEND_TV_RESISTANCE_MAX);
                    resistanceMin = deviceData.getResistanceMin();
                    handler.sendEmptyMessage(SEND_TV_RESISTANCE_MIN);
                    resistanceMode = deviceData.getResistanceMode();
                    handler.sendEmptyMessage(SEND_TV_RESISTANCE_MODE);
                    speedRange = deviceData.getSpeedRange();
                    handler.sendEmptyMessage(SEND_TV_SPEED_RANGE);
                    inclineRange = deviceData.getInclineRange();
                    handler.sendEmptyMessage(SEND_TV_INCLINE_RANGE);
                }

                @Override
                public void onMachineStatus(MachineStatusBeen machineStatus) {
                    status = machineStatus.getMachineStatus();
                    handler.sendEmptyMessage(SEND_TV_MACHINE_STATUS);
                    machineEnterStateMethod = machineStatus.getMachineEnterStateMethod();
                    handler.sendEmptyMessage(SEND_TV_MACHINE_ENTER_STATE_METHOD);
                }

                @Override
                public void onResistanceData(ResistanceDataBean resistanceData) {
                    resistance = resistanceData.getResistance();
                    handler.sendEmptyMessage(SEND_TV_RESISTANCE);
                }

                @Override
                public void onSignalTimeData(SignalTimeDataBean signalTimeData) {
                    signalTimeInterval = signalTimeData.getSignalTimeInterval();
                    handler.sendEmptyMessage(SEND_TV_SIGNAL_TIME_INTERVAL);
                    signalCount = signalTimeData.getSignalCount();
                    handler.sendEmptyMessage(SEND_TV_SIGNAL_COUNT);

                }

                @Override
                public void onTreadmillSportData(TreadmillSportDataBean sportData) {
                    speed = sportData.getSpeed();
                    handler.sendEmptyMessage(SEND_TV_SPEED);
                    incline = sportData.getIncline();
                    handler.sendEmptyMessage(SEND_TV_INCLINE);
                    step = sportData.getStep();
                    handler.sendEmptyMessage(SEND_TV_STEP);
                    time = sportData.getTime();
                    handler.sendEmptyMessage(SEND_TV_TIME);
                    distance = sportData.getDistance();
                    handler.sendEmptyMessage(SEND_TV_DISTANCE);
                    calories = sportData.getCalories();
                    handler.sendEmptyMessage(SEND_TV_CALORIES);
                }

                @Override
                public void onHeartbeatValue(int heartbeat) {
                    pulse = heartbeat;
                    handler.sendEmptyMessage(SEND_TV_HEARTBEAT);
                }

                @Override
                public void onErrorCode(ErrorCodeBean errorCode) {
                    errorCodeHi = errorCode.getErrorCodeHi();
                    errorCodeLow = errorCode.getErrorCodeLow();
                    handler.sendEmptyMessage(SEND_TV_ERROR_CODE);
                }

                @Override
                public void onFailure(String msg) {

                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Handler handler = new Handler((new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message message) {
            switch (message.what) {
                case SEND_TV_MANUFACTURER_NAME:
                    mTvManufacturerName.setText(manufacturerName);
                    return true;
                case SEND_TV_MODEL_NUMBER:
                    mTvModelNumber.setText(modelNumber);
                    return true;
                case SEND_TV_HARDWARE_REVISION:
                    mTvHardwareRevision.setText(hardwareRevision);
                    return true;
                case SEND_TV_FIRMWARE_REVISION:
                    mTvFirmwareRevision.setText(firmwareRevision);
                    return true;
                case SEND_TV_DATA_REPORTING_METHOD:
                    mTvDataReportingMethod.setText(String.valueOf(dataReportingMethod));
                    return true;
                case SEND_TV_DEVICE_TYPE:
                    mTvDeviceType.setText(String.valueOf(deviceType));
                    return true;
                case SEND_TV_DEVICE_SUBTYPE:
                    mTvDeviceSubType.setText(String.valueOf(deviceSubType));
                    return true;
                case SEND_TV_DEVICE_CONTROL_TYPE:
                    mTvDeviceControlType.setText(String.valueOf(deviceControlType));
                    return true;
                case SEND_TV_SENSOR_SIGNAL_SCALE:
                    mTvSensorSignalScale.setText(String.valueOf(sensorSignalScale));
                    return true;
                case SEND_TV_NUMBER_OF_MAGNETS:
                    mTvNumberOfMagnets.setText(String.valueOf(numberOfMagnets));
                    return true;
                case SEND_TV_BATTERY:
                    mTvBattery.setText(String.valueOf(battery));
                    return true;
                case SEND_TV_RESISTANCE_MAX:
                    mTvResistanceMax.setText(String.valueOf(resistanceMax));
                    return true;
                case SEND_TV_RESISTANCE_MIN:
                    mTvResistanceMin.setText(String.valueOf(resistanceMin));
                    return true;
                case SEND_TV_RESISTANCE_MODE:
                    mTvResistanceMode.setText(String.valueOf(resistanceMode));
                    return true;
                case SEND_TV_SPEED_RANGE:
                    String strSpd = speedRange[0] + "/" + speedRange[1];
                    mTvSpeedRange.setText(strSpd);
                    return true;
                case SEND_TV_INCLINE_RANGE:
                    String strInc = inclineRange[0] + "/" + inclineRange[1];
                    mTvInclineRange.setText(strInc);
                    return true;
                case SEND_TV_MACHINE_STATUS:
                    mTvMachineStatus.setText(String.valueOf(status));
                    return true;
                case SEND_TV_MACHINE_ENTER_STATE_METHOD:
                    mTvMachineEnterStateMethod.setText(String.valueOf(machineEnterStateMethod));
                    return true;
                case SEND_TV_ERROR_CODE:
                    String strErr = errorCodeHi + "/" + errorCodeLow;
                    mTvErrorCode.setText(strErr);
                    return true;
                case SEND_TV_RESISTANCE:
                    mTvResistance.setText(String.valueOf(resistance));
                    return true;
                case SEND_TV_SIGNAL_TIME_INTERVAL:
                    mTvSignalTimeInterval.setText(String.valueOf(signalTimeInterval));
                    return true;
                case SEND_TV_SIGNAL_COUNT:
                    mTvSignalCount.setText(String.valueOf(signalCount));
                    return true;
                case SEND_TV_SPEED:
                    mTvSpeed.setText(String.valueOf(speed));
                    return true;
                case SEND_TV_INCLINE:
                    mTvIncline.setText(String.valueOf(incline));
                    return true;
                case SEND_TV_STEP:
                    mTvStep.setText(String.valueOf(step));
                    return true;
                case SEND_TV_TIME:
                    mTvTime.setText(String.valueOf(time));
                    return true;
                case SEND_TV_DISTANCE:
                    mTvDistance.setText(String.valueOf(distance));
                    return true;
                case SEND_TV_CALORIES:
                    mTvCalories.setText(String.valueOf(calories));
                    return true;
                case SEND_TV_HEARTBEAT:
                    mTvHeartbeat.setText(String.valueOf(pulse));
                    return true;
            }
            return false;
        }
    }));

    @Override
    protected void onDestroy() {
        super.onDestroy();
        MoBiDevice.destroy();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.mBtSetSpeed:
                if (mEtSetSpeed.length() != 0) {
                    MoBiDevice.controlSpeed(Integer.parseInt(mEtSetSpeed.getText().toString()));
                }
                break;
            case R.id.mBtSetIncline:
                if (mEtSetIncline.length() != 0) {
                    MoBiDevice.controlIncline(Integer.parseInt(mEtSetIncline.getText().toString()));
                }
                break;
            case R.id.mBtSetResistance:
                if (mEtSetResistance.length() != 0) {
                    MoBiDevice.controlResistance(Integer.parseInt(mEtSetResistance.getText().toString()));
                }
                break;
            case R.id.mBtStop:
                MoBiDevice.controlStatus(1);
                break;
            case R.id.mBtStart:
                MoBiDevice.controlStatus(0);
                break;
            case R.id.mBtPause:
                MoBiDevice.controlStatus(2);
                break;
            default:
                break;
        }
    }
}
