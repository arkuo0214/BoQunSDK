package com.boqun.mobisdkdemo;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import com.boqun.mobisdk.uart.BikeDataBean;
import com.boqun.mobisdk.uart.DeviceCheck;
import com.boqun.mobisdk.uart.MoBiBike;
import com.boqun.mobisdk.uart.MoBiDeviceCheck;
import com.boqun.mobisdk.uart.MoBiTreadmill;
import com.boqun.mobisdk.uart.OnBikeDataCallback;
import com.boqun.mobisdk.uart.OnDeviceCheckDataCallback;
import com.boqun.mobisdk.uart.OnTreadmillDataCallback;
import com.boqun.mobisdk.uart.Treadmill;


public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();
    private Context mContext = null;
    private int mDeviceName = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContext = this;

        try {
            MoBiDeviceCheck.init(mContext, new OnDeviceCheckDataCallback() {
                @Override
                public void onCheckSuccess(int device) {
                    Log.e(TAG,"onCreate->MoBiDeviceCheck.init->onCheckSuccess:"+device);
                    mDeviceName = device;
                    if (device == DeviceCheck.BIKE) {
                        try {
                            MoBiBike.init(mContext, new OnBikeDataCallback() {
                                @Override
                                public void onSportData(BikeDataBean bean) {
                                    Log.e(TAG,"onCreate->MoBiDeviceCheck.init->onSportData");
                                }
                            });
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    } else if (device == DeviceCheck.TREADMILL) {
                        try {
                            MoBiTreadmill.init(mContext, new OnTreadmillDataCallback() {
                                @Override
                                public void onExternalKeyEvent(int action, int keyCode) {
                                    Log.e(TAG,"onCreate->MoBiTreadmill.init->onExternalKeyEvent:action="+action+"/keyCode="+keyCode);
                                }

                                @Override
                                public void onStateChange(boolean isRefueling, boolean isLackOil, boolean isECOStatus, boolean isFactoryMode, int heartbeat) {
                                    Log.e(TAG,"onCreate->MoBiTreadmill.init->onStateChange->heartbeat:"+heartbeat);
                                }

                                @Override
                                public void onError(int error) {
                                    Log.e(TAG,"onCreate->MoBiTreadmill.init->onError"+error);
                                }

                                @Override
                                public void onReadVersion(int downControlVersion, int transferBoardVersion) {
                                    Log.e(TAG,"onCreate->MoBiTreadmill.init->onReadVersion:"+downControlVersion+"/"+transferBoardVersion);
                                }

                                @Override
                                public void onFuelMileageChange(int fuelMileage) {
                                    Log.e(TAG,"onCreate->MoBiTreadmill.init->onFuelMileageChange:"+fuelMileage);
                                }

                                @Override
                                public void onRefuelingTimeChange(int refuelingTime) {
                                    Log.e(TAG,"onCreate->MoBiTreadmill.init->onRefuelingTimeChange:"+refuelingTime);
                                }

                                @Override
                                public void onMotorCurrentValue(float value) {
                                    Log.e(TAG,"onCreate->MoBiTreadmill.init->onMotorCurrentValue:"+value);
                                }

                                @Override
                                public void onMotorVoltageValue(int value) {
                                    Log.e(TAG,"onCreate->MoBiTreadmill.init->onMotorVoltageValue:"+value);
                                }

                                @Override
                                public void onStepCountChange(int stepCount) {
                                    Log.e(TAG,"onCreate->MoBiTreadmill.init->onStepCountChange:"+stepCount);
                                }

                                @Override
                                public void onFactoryModeSettingInfo(boolean isAutomaticShutdownEnable) {
                                    Log.e(TAG,"onCreate->MoBiTreadmill.init->onFactoryModeSettingInfo:"+isAutomaticShutdownEnable);
                                }
                            });
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                }

                @Override
                public void onCheckFailure() {
                    Log.e(TAG,"onCreate->MoBiDeviceCheck.init->onCheckFailure");
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }


        //bike
//        MoBiBike.sendPortMessage();
//        MoBiBike.sendPortMessageDelay();


        //Treadmill
//        MoBiTreadmill.setInclineAndSpeed(6,20,true);
//        MoBiTreadmill.setSportModeAndStatus(Treadmill.TREADMILL_MODE, Treadmill.STATUS_PROGRAM_SETUP, true);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mDeviceName == DeviceCheck.BIKE) {
            MoBiBike.destroy();
        } else if (mDeviceName == DeviceCheck.TREADMILL) {
            MoBiTreadmill.destroy();
        }
    }
}
