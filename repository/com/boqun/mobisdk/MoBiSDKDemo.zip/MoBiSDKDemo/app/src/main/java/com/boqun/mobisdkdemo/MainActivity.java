package com.boqun.mobisdkdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.boqun.mobisdk.uart.BoQunBike;
import com.boqun.mobisdk.uart.PortDataBean;
import com.boqun.mobisdk.uart.PortDataCallback;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            BoQunBike.init(this, new PortDataCallback() {
                @Override
                public void onSportData(PortDataBean bean) {
                    super.onSportData(bean);
                    int equipmentType = bean.getEquipmentType();
                    int equipmentSubType = bean.getEquipmentSubType();
                    int battery = bean.getBattery();
                    long rpm = bean.getRpm();
                    long count = bean.getCount();
                    int load = bean.getLoad();
                    int pulse = bean.getPulse();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

        BoQunBike.sendPortMessageDelay("AB010000000000",500);       //auto CheckSum
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        BoQunBike.destroy();
    }
}
