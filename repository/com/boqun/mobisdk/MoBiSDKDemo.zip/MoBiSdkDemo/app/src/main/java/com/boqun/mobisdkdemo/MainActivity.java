package com.boqun.mobisdkdemo;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import com.boqun.mobisdk.uart.BikeDataBean;
import com.boqun.mobisdk.uart.MoBiBike;
import com.boqun.mobisdk.uart.MoBiTreadmill;
import com.boqun.mobisdk.uart.OnBikeDataCallback;
import com.boqun.mobisdk.uart.OnTreadmillDataCallback;
import com.boqun.mobisdk.uart.Treadmill;


public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //bike
//        try {
//            MoBiBike.init(this, new OnBikeDataCallback() {
//                @Override
//                public void onSportData(BikeDataBean bean) {
//                    Log.e(TAG, "onSportData: " + bean.getRpm());
//                }
//            });
//        } catch (Exception e) {
//            e.printStackTrace();
//        }

//        MoBiBike.sendPortMessage();
//        MoBiBike.sendPortMessageDelay();

        //Treadmill

        try {
            MoBiTreadmill.init(this, new OnTreadmillDataCallback() {
                @Override
                public void onExternalKeyEvent(int action, int keyCode) {
                    Log.e(TAG, "onExternalKeyEvent: " + action + " keyCode: " + keyCode);
                }

                @Override
                public void onStateChange(boolean isRefueling, boolean isLackOil, boolean isECOStatus, boolean isFactoryMode, int heartbeat) {
                    Log.e(TAG, "onStateChange: Heartbeat: " + heartbeat);
                }

                @Override
                public void onError(int error) {
                    Log.e(TAG, "onError: " + error);
                }

                @Override
                public void onReadVersion(int downControlVersion, int transferBoardVersion) {

                }

                @Override
                public void onFuelMileageChange(int fuelMileage) {

                }

                @Override
                public void onRefuelingTimeChange(int refuelingTime) {

                }

                @Override
                public void onMotorCurrentValue(float value) {

                }

                @Override
                public void onMotorVoltageValue(int value) {

                }

                @Override
                public void onStepCountChange(int stepCount) {
                    Log.e(TAG, "onStepCountChange: " + stepCount);
                }

                @Override
                public void onFactoryModeSettingInfo(boolean isAutomaticShutdownEnable) {

                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

//        MoBiTreadmill.setInclineAndSpeed(6,20,true);
//        MoBiTreadmill.setSportModeAndStatus(Treadmill.TREADMILL_MODE, Treadmill.STATUS_PROGRAM_SETUP, true);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

//        MoBiBike.destroy();

        MoBiTreadmill.destroy();
    }
}
