package com.boqun.xqportsdkdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.boqun.xqportsdk.urat.OnBikeDataListener;
import com.boqun.xqportsdk.urat.XQBike;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        XQBike.init(this, new OnBikeDataListener() {
            @Override
            public void onInitializationSuccess(String s) {
                Log.e("MainActivity","onCreate->XQBike.init->onInitializationSuccess->serialNumber:"+s);
            }

            @Override
            public void onDataChange(int i, int i1, int i2) {
                Log.e("MainActivity","onCreate->XQBike.init->onDataChange->watt:"+i+";rpm:"+i1+";level:"+i2);
            }
        });

    }
}
