package com.boqun.iconsolesdk.demo

import android.app.Application
import com.boqun.iconsole.sdk.treadmill.advanced.BoQunAdvanced

/**
 * @Description TODO
 * @Author Felix
 * @Date 2025/7/3 9:32
 */
class App : Application() {

    override fun onCreate() {
        super.onCreate()

        BoQunAdvanced.init("e1d30e74ad10b0d0dc605f7e0b1350d1", this)

    }
}