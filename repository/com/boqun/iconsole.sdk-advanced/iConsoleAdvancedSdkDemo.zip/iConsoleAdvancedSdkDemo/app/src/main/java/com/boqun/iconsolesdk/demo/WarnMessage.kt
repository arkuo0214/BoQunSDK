package com.boqun.iconsolesdk.demo

import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.graphics.Color
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.TextView

/**
 * @Description TODO
 * @Author Felix
 * @Date 2025/7/3 8:36
 */
object WarnMessage {

    private var map = hashMapOf<String, IWarnMessage>()

    private const val KEY_SAFE_KEY = "safe_key"

    private const val KEY_COOL_DOWN = "cool_down"

    private const val KEY_MESSAGE = "message"

    private fun show(context: Context, key: String, message: String, cancelable: Boolean) {
        var dialog = map[key]
        if (dialog == null) {
            dialog = WarnMessage(context, message).apply {
                setCancelable(cancelable)
                setOnDismissListener {
                    map.remove(key)
                }
            }
            map[key] = dialog
        }
        if (!dialog.isShowing()) {
            dialog.show()
        }
        dialog.setMessage(message)
    }

    private fun dismiss(key: String) {
        map[key]?.dismiss()
        map.remove(key)
    }

    fun dismissAll() {
        map.forEach {
            it.value.dismiss()
        }
        map.clear()
    }

    fun showSafeKey(context: Context, message: String) {
        show(context, KEY_SAFE_KEY, message, false)
    }

    fun dismissSafeKey() {
        dismiss(KEY_SAFE_KEY)
    }

    fun showCoolDown(context: Context, message: String) {
        show(context, KEY_COOL_DOWN, message, true)
    }

    fun dismissCoolDown() {
        dismiss(KEY_COOL_DOWN)
    }

    fun show(context: Context, message: String, cancelable: Boolean = true) {
        show(context, KEY_MESSAGE, message, cancelable)
    }

    fun dismiss() {
        dismiss(KEY_MESSAGE)
    }

    interface IWarnMessage {

        fun show()

        fun dismiss()

        fun isShowing(): Boolean

        fun setMessage(message: String)
    }

    class WarnMessage(context: Context, private var message: String? = null) : Dialog(context),
        IWarnMessage {

        private var textView: TextView? = null

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            textView = TextView(context).apply {
                text = message
                setTextColor(Color.RED)
                textSize = 32.sp
                layoutParams= FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                ).apply {
                    gravity = Gravity.CENTER
                }
            }
            setContentView(FrameLayout(context).apply {
                layoutParams = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                ).apply {
                    setPadding(20.dp, 20.dp, 20.dp, 20.dp)
                    minimumWidth = 300.dp
                    minimumHeight = 100.dp
                }
                addView(textView)
            })
        }

        val Int.dp: Int
            get() {
                return TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_DIP,
                    this.toFloat(),
                    context.resources.displayMetrics
                ).toInt()
            }

        val Int.sp: Float
            get() {
                return TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_SP,
                    this.toFloat(),
                    context.resources.displayMetrics
                )
            }

        override fun onSaveInstanceState(): Bundle {
            val state = super.onSaveInstanceState()
            state.putString("message", message)
            return state
        }

        override fun onRestoreInstanceState(savedInstanceState: Bundle) {
            super.onRestoreInstanceState(savedInstanceState)
            message = savedInstanceState.getString("message")
        }

        override fun setMessage(message: String) {
            this.message = message
            textView?.text = message
        }

        override fun show() {
            super.show()
        }

        override fun dismiss() {
            super.dismiss()
        }

        override fun isShowing(): Boolean {
            return super.isShowing()
        }

        override fun onDetachedFromWindow() {
            super.onDetachedFromWindow()
            textView = null
        }
    }
}