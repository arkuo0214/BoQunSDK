package com.boqun.iconsolesdk.demo

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import com.boqun.iconsole.sdk.treadmill.advanced.BoQunTreadmillAdvanced
import com.boqun.iconsole.sdk.treadmill.advanced.CoolDownState
import com.boqun.iconsole.sdk.treadmill.advanced.LevelType
import com.boqun.iconsole.sdk.treadmill.advanced.SportState
import com.boqun.iconsole.sdk.treadmill.advanced.data.TreadmillSportData
import com.boqun.iconsolesdk.demo.databinding.ActivityMainBinding

/**
 * @Description TODO
 * @Author Felix
 * @Date 2025/7/2 16:50
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private var treadmill: BoQunTreadmillAdvanced? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        treadmill = BoQunTreadmillAdvanced(applicationContext).apply {
            onTreadmillAdvancedListener = object :
                BoQunTreadmillAdvanced.OnTreadmillAdvancedListener {
                override fun onTreadmillConnected() {

                }

                override fun onSportStateChanged(state: Int) {
                    when (state) {
                        SportState.STATE_START -> {
                            binding.pauseHint.isVisible = true
                            binding.sportControl.isVisible = false
                        }

                        SportState.STATE_PAUSE -> {
                            //暂停运动
                            binding.pauseHint.isVisible = false
                            binding.sportControl.isVisible = true
                            binding.start.text = "Resume"
                        }

                        SportState.STATE_STOP -> {
                            //停止运动
                            binding.pauseHint.isVisible = false
                            binding.sportControl.isVisible = true
                            binding.start.text = "Start"
                        }
                    }
                }

                override fun onSportLevelChanged(type: Int, level: Int) {
                    if (type == LevelType.SPEED) {
                        binding.speed.text = "%.1f".format(level / 10.0)
                    } else if (type == LevelType.INCLINE) {
                        binding.incline.text = "%d%%".format(level)
                    } else if (type == LevelType.FAN) {
                        //Fan level
                    }
                }

                override fun onSportDataUpdate(data: TreadmillSportData) {
                    //Background thread

                }

                override fun onSportDataPostUpdate(data: TreadmillSportData) {
                    //Main thread

                    val minute = data.time / 60
                    val second = data.time % 60
                    binding.time.text = "%02d:%02d".format(minute, second)
                    binding.distance.text = if (treadmill?.isImperial == true) {
                        "%.1f mi".format(data.distance.mi)
                    } else {
                        "%.1f km".format(data.distance.km)
                    }
                    binding.calories.text = "%d kcal".format(data.calories.toInt())
                }

                override fun onTreadmillSafetyKeyStatus(normal: Boolean) {
                    if (!normal) {
                        WarnMessage.dismissCoolDown()
                        WarnMessage.showSafeKey(
                            this@MainActivity,
                            "Please put the safety lock in the correct position"
                        )
                        //If the safety key is abnormal, stop the movement immediately
                        treadmill?.stop()
                    } else {
                        WarnMessage.dismissSafeKey()
                    }
                }

                override fun onTreadmillCoolDownStatus(status: Int, speed: Int) {
                    when (status) {
                        CoolDownState.STATE_START -> {
                            WarnMessage.showCoolDown(this@MainActivity, "Cooling down, please wait")
                        }

                        CoolDownState.STATE_RUNNING -> {
                            WarnMessage.showCoolDown(
                                this@MainActivity,
                                "Cooling down ${speed}, please wait"
                            )
                        }

                        CoolDownState.STATE_END -> {
                            WarnMessage.dismissCoolDown()
                        }
                    }
                }

                override fun onTreadmillDisconnected() {

                }

                override fun onTreadmillError(errorCode: Int) {
                    WarnMessage.show(this@MainActivity, "%02X".format(errorCode))
                }
            }
            //After pausing, resume whether to restore the speed before pausing
            allowRestoreSpeed = true

            //Km or mi
            isImperial = true
            connect()
        }

        binding.root.setOnClickListener {
            treadmill?.pause()
        }

        binding.start.setOnClickListener {
            treadmill?.start()
        }

        binding.stop.setOnClickListener {
            treadmill?.stop()
        }

        binding.speedUp.setOnClickListener {
            treadmill?.speedUp()
        }

        binding.speedDown.setOnClickListener {
            treadmill?.speedDown()
        }

        binding.inclineUp.setOnClickListener {
            treadmill?.inclineUp()
        }

        binding.inclineDown.setOnClickListener {
            treadmill?.inclineDown()
        }
    }

    val Double.km: Double
        get() {
            return this / 1000.0
        }

    val Double.mi: Double
        get() {
            return this / 1609.0
        }

    override fun onDestroy() {
        super.onDestroy()
        treadmill?.disconnect()
        treadmill = null
    }


}