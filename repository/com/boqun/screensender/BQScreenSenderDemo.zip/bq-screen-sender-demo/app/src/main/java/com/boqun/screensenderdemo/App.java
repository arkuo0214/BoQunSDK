package com.boqun.screensenderdemo;

import android.app.Application;

import com.boqun.screensender.aircast.RenderApplication;

public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();

        RenderApplication.init(this);

    }
}
