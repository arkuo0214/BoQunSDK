package com.boqun.screensenderdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.boqun.screensender.sender.app.BQSSMainActivity;
import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    MaterialButton mTvScreenSender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTvScreenSender = findViewById(R.id.mTvScreenSender);

        mTvScreenSender.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        int viewId = view.getId();
        if (viewId == R.id.mTvScreenSender) {
            Intent intent = new Intent(this, BQSSMainActivity.class);
            intent.putExtra("APPID", "66e4f2c3dd5587a329c504d11947e957");
            this.startActivity(intent);
        }
    }
}