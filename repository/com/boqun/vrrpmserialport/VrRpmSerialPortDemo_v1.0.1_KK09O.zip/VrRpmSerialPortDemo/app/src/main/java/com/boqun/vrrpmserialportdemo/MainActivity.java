package com.boqun.vrrpmserialportdemo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.TextView;

import com.boqun.vrrpmserialport.uart.OnBikeDataListener;
import com.boqun.vrrpmserialport.uart.VrRpmBike;

public class MainActivity extends AppCompatActivity {

    private static final int SEND_TV_SerialNumber = 0;
    private static final int SEND_TV_Watt = 1;
    private static final int SEND_TV_RPM = 2;
    private static final int SEND_TV_Level = 3;

    private static final String TAG = MainActivity.class.getSimpleName();
    private Context mContext = null;

    private TextView mTvSerialNumber;
    private TextView mTvWatt;
    private TextView mTvRpm;
    private TextView mTvLevel;

    private String mSerialNumber;
    private int mWatt;
    private int mRpm;
    private int mLevel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mContext = this;

        mTvSerialNumber = findViewById(R.id.mTvSerialNumber);
        mTvWatt = findViewById(R.id.mTvWatt);
        mTvRpm = findViewById(R.id.mTvRpm);
        mTvLevel = findViewById(R.id.mTvLevel);

        try {
            VrRpmBike.init(mContext, new OnBikeDataListener() {
                @Override
                public void onInitializationSuccess(String serialNumber) {
                    mSerialNumber = serialNumber;
                    handler.sendEmptyMessage(SEND_TV_SerialNumber);
                }

                @Override
                public void onDataChange(int watt, int rpm, int level) {
                    mWatt = watt;
                    mRpm = rpm;
                    mLevel = level;
                    handler.sendEmptyMessage(SEND_TV_Watt);
                    handler.sendEmptyMessage(SEND_TV_RPM);
                    handler.sendEmptyMessage(SEND_TV_Level);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Handler handler = new Handler((new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message message) {
            String data;
            switch (message.what) {
                case SEND_TV_SerialNumber:
                    mTvSerialNumber.setText(mSerialNumber);
                    return true;
                case SEND_TV_Watt:
                    mTvWatt.setText(String.valueOf(mWatt));
                    return true;
                case SEND_TV_RPM:
                    mTvRpm.setText(String.valueOf(mRpm));
                    return true;
                case SEND_TV_Level:
                    mTvLevel.setText(String.valueOf(mLevel));
                    return true;
            }
            return false;
        }
    }));
}
