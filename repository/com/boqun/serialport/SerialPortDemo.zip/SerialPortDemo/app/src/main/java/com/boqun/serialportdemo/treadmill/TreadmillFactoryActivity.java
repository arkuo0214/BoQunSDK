package com.boqun.serialportdemo.treadmill;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.boqun.serialportdemo.BaseActivity;
import com.boqun.serialportdemo.R;
import com.boqun.uart.treadmill.BoQunTreadmill;
import com.boqun.uart.treadmill.CorrectionState;
import com.boqun.uart.treadmill.FactoryDataBean;
import com.boqun.uart.treadmill.FactoryParams;
import com.boqun.uart.treadmill.TreadmillFactory;

public class TreadmillFactoryActivity extends BaseActivity implements View.OnClickListener {

    private TextView mTvParameterSetting;
    private TextView mTvWheelDiameter;
    private TextView mTvWheelDiameterValue;
    private TextView mTvInclineVRMax;
    private TextView mTvInclineVRMaxValue;
    private TextView mTvInclineVRMin;
    private TextView mTvInclineVRMinValue;
    private TextView mTvSpeedMax;
    private TextView mTvSpeedMaxValue;
    private TextView mTvSpeedMin;
    private TextView mTvSpeedMinValue;
    private TextView mTvSpeedIncrement;
    private TextView mTvSpeedIncrementValue;
    private TextView mTvMotorInitPulse;
    private TextView mTvMotorInitPulseValue;
    private TextView mTvOneKmVoltage;
    private TextView mTvOneKmVoltageValue;
    private TextView mTvLightRatio;
    private TextView mTvLightRatioValue;
    private TextView mTvTorque;
    private TextView mTvTorqueValue;
    private TextView mTvKilometerMiles;
    private TextView mTvKilometerMilesValue;
    private TextView mTvCurrentLimit;
    private TextView mTvCurrentLimitValue;
    private TextView mTvTenKmVoltage;
    private TextView mTvTenKmVoltageValue;
    private TextView mTvTemperatureInductance;
    private TextView mTvTemperatureInductanceValue;
    private TextView mTvFeelUnsatisfied;
    private TextView mTvFeelUnsatisfiedValue;
    private TextView mTvAutomaticCorrection;
    private TextView mTvSpeedCorrection;
    private TextView mTvSpeedAndInclineCorrectionValue;
    private TextView mTvRealSpeedValue;
    private TextView mTvInclineAdcValue;

    private boolean isAutoCalibration = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.treadmill_factory_layout);

      initActionBar("Treadmill Factory",true);

        mTvParameterSetting = findViewById(R.id.mTvParameterSetting);
        mTvWheelDiameter = findViewById(R.id.mTvWheelDiameter);
        mTvWheelDiameterValue = findViewById(R.id.mTvWheelDiameterValue);
        mTvInclineVRMax = findViewById(R.id.mTvInclineVRMax);
        mTvInclineVRMaxValue = findViewById(R.id.mTvInclineVRMaxValue);
        mTvInclineVRMin = findViewById(R.id.mTvInclineVRMin);
        mTvInclineVRMinValue = findViewById(R.id.mTvInclineVRMinValue);
        mTvSpeedMax = findViewById(R.id.mTvSpeedMax);
        mTvSpeedMaxValue = findViewById(R.id.mTvSpeedMaxValue);
        mTvSpeedMin = findViewById(R.id.mTvSpeedMin);
        mTvSpeedMinValue = findViewById(R.id.mTvSpeedMinValue);
        mTvSpeedIncrement = findViewById(R.id.mTvSpeedIncrement);
        mTvSpeedIncrementValue = findViewById(R.id.mTvSpeedIncrementValue);
        mTvMotorInitPulse = findViewById(R.id.mTvMotorInitPulse);
        mTvMotorInitPulseValue = findViewById(R.id.mTvMotorInitPulseValue);
        mTvOneKmVoltage = findViewById(R.id.mTvOneKmVoltage);
        mTvOneKmVoltageValue = findViewById(R.id.mTvOneKmVoltageValue);
        mTvLightRatio = findViewById(R.id.mTvLightRatio);
        mTvLightRatioValue = findViewById(R.id.mTvLightRatioValue);
        mTvTorque = findViewById(R.id.mTvTorque);
        mTvTorqueValue = findViewById(R.id.mTvTorqueValue);
        mTvKilometerMiles = findViewById(R.id.mTvKilometerMiles);
        mTvKilometerMilesValue = findViewById(R.id.mTvKilometerMilesValue);
        mTvCurrentLimit = findViewById(R.id.mTvCurrentLimit);
        mTvCurrentLimitValue = findViewById(R.id.mTvCurrentLimitValue);
        mTvTenKmVoltage = findViewById(R.id.mTvTenKmVoltage);
        mTvTenKmVoltageValue = findViewById(R.id.mTvTenKmVoltageValue);
        mTvTemperatureInductance = findViewById(R.id.mTvTemperatureInductance);
        mTvTemperatureInductanceValue = findViewById(R.id.mTvTemperatureInductanceValue);
        mTvFeelUnsatisfied = findViewById(R.id.mTvFeelUnsatisfied);
        mTvFeelUnsatisfiedValue = findViewById(R.id.mTvFeelUnsatisfiedValue);
        mTvAutomaticCorrection = findViewById(R.id.mTvAutomaticCorrection);
        mTvSpeedCorrection = findViewById(R.id.mTvSpeedCorrection);
        mTvSpeedAndInclineCorrectionValue = findViewById(R.id.mTvSpeedAndInclineCorrectionValue);
        mTvRealSpeedValue = findViewById(R.id.mTvRealSpeedValue);
        mTvInclineAdcValue = findViewById(R.id.mTvInclineAdcValue);

        mTvSpeedAndInclineCorrectionValue.setOnClickListener(this);

        BoQunTreadmill.getFactory().init(new TreadmillFactory.OnFactoryListener() {
            @Override
            public void onFactoryDataChange(FactoryDataBean bean) {
                handler.obtainMessage(UPDATE_FACTORY_DATA, bean).sendToTarget();
            }

            @Override
            public void onAutoCorrection(int status, int realSpeed, int motorAdc, int inclineVR) {
                if (status == CorrectionState.CORRECTION_START) {
                    isAutoCalibration = true;
                    handler.obtainMessage(UPDATE_AUTO_CORRECTION, 0, 0).sendToTarget();
                } else if (status == CorrectionState.CORRECTION_ING) {
                    isAutoCalibration = true;
                    handler.obtainMessage(UPDATE_AUTO_CORRECTION, realSpeed, motorAdc).sendToTarget();
                } else if (status == CorrectionState.CORRECTION_STOP) {
                    isAutoCalibration = false;
                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        if (isAutoCalibration) {
            Toast.makeText(getContext(), "Auto calibration...", Toast.LENGTH_LONG).show();
            return;
        }
        int id = v.getId();
        if (id == R.id.mTvSpeedAndInclineCorrectionValue) {
            BoQunTreadmill.getFactory().startAutoCorrection();
        }
    }

    public Context getContext() {
        return this;
    }

    private static final int UPDATE_FACTORY_DATA = 1;

    private static final int UPDATE_AUTO_CORRECTION = 2;

    private Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            switch (msg.what) {
                case UPDATE_FACTORY_DATA:
                    FactoryDataBean bean = (FactoryDataBean) msg.obj;
                    mTvWheelDiameterValue.setText(String.valueOf(bean.getWheelDiameter()));
                    mTvInclineVRMaxValue.setText(String.valueOf(bean.getMaxInclineVRValue()));
                    mTvInclineVRMinValue.setText(String.valueOf(bean.getMinInclineVRValue()));
                    mTvSpeedMaxValue.setText(String.valueOf(bean.getMaxSpeedValue()));
                    mTvSpeedMinValue.setText(String.valueOf(bean.getMinSpeedValue()));
                    mTvSpeedIncrementValue.setText(String.valueOf(bean.getSpeedIncrementValue()));

                    mTvMotorInitPulseValue.setText(String.valueOf(bean.getMotorStartPulse()));
                    mTvOneKmVoltageValue.setText(String.valueOf(bean.getKm1VoltageValue()));
                    mTvTenKmVoltageValue.setText(String.valueOf(bean.getKm10VoltageValue()));
                    mTvLightRatioValue.setText(String.valueOf(bean.getLightPerceptionRatio()));
                    mTvTorqueValue.setText(String.valueOf(bean.getTorqueValue()));
                    mTvCurrentLimitValue.setText(String.valueOf(bean.getLineCurrentValue()));

                    mTvFeelUnsatisfiedValue.setText(String.valueOf(bean.getInductionMethod()));
                    mTvKilometerMilesValue.setText(String.valueOf(bean.getMileSwitch()));

                    mTvTemperatureInductanceValue.setText(String.valueOf(bean.getPA_PB()));
                    break;
                case UPDATE_AUTO_CORRECTION:
                    int realSpeed = msg.arg1;
                    int inclineAdc = msg.arg2;
                    mTvRealSpeedValue.setText(String.valueOf(realSpeed));
                    mTvInclineAdcValue.setText(String.valueOf(inclineAdc));
                    break;
                default:
                    break;
            }
            return true;
        }
    });

    //轮径
    public void setWheelDiameter(int wheelDiameter) {
        BoQunTreadmill.getFactory().setFactoryParams(FactoryParams.WHEEL_DIAMETER, wheelDiameter);
    }

    //揚升VR最高值
    public void setMaxInclineVRValue(int maxInclineVRValue) {
        BoQunTreadmill.getFactory().setFactoryParams(FactoryParams.MAX_INCLINE_VR, maxInclineVRValue);
    }

    //揚升VR最低值
    public void setMinInclineVRValue(int minInclineVRValue) {
        BoQunTreadmill.getFactory().setFactoryParams(FactoryParams.MIN_INCLINE_VR, minInclineVRValue);
    }

    //最高速度
    public void setMaxSpeedValue(int maxSpeedValue) {
        BoQunTreadmill.getFactory().setFactoryParams(FactoryParams.MAX_SPEED, maxSpeedValue);
    }

    //最低速度
    public void setMinSpeedValue(int minSpeedValue) {
        BoQunTreadmill.getFactory().setFactoryParams(FactoryParams.MIN_SPEED, minSpeedValue);
    }

    //速度增量
    public void setSpeedIncrementValue(int speedIncrementValue) {
        BoQunTreadmill.getFactory().setFactoryParams(FactoryParams.CHILD_SPEED, speedIncrementValue);
    }

    //揚升開關
    public void setInclineSwitch(int inclineSwitch) {
        BoQunTreadmill.getFactory().setFactoryParams(FactoryParams.INCLINE_SWITCH, inclineSwitch);
    }

    //揚升最大段
    public void setMaxInclineValue(int maxInclineValue) {
        BoQunTreadmill.getFactory().setFactoryParams(FactoryParams.MAX_INCLINE, maxInclineValue);
    }

    //負揚升 /	揚升最低段
    public void setMinInclineValue(int minInclineValue) {
        BoQunTreadmill.getFactory().setFactoryParams(FactoryParams.MIN_INCLINE, minInclineValue);
    }

    //馬達起始 pulse
    public void setMotorStartPulse(int motorStartPulse) {
        BoQunTreadmill.getFactory().setFactoryParams(FactoryParams.MOTOR_INIT_PULSE, motorStartPulse);
    }

    //1公里電壓值
    public void setKm1VoltageValue(int km1VoltageValue) {
        BoQunTreadmill.getFactory().setFactoryParams(FactoryParams.ONE_KM_VOLTAGE, km1VoltageValue);
    }

    //10公里電壓值
    public void setKm10VoltageValue(int km10VoltageValue) {
        BoQunTreadmill.getFactory().setFactoryParams(FactoryParams.TEN_KM_VOLTAGE, km10VoltageValue);
    }

    //滾筒皮帶輪/馬達皮帶輪*50=光感配比
    public void setLightPerceptionRatio(int lightPerceptionRatio) {
        BoQunTreadmill.getFactory().setFactoryParams(FactoryParams.LIGHT_PERCEPTION_RATIO, lightPerceptionRatio);
    }

    //扭力值
    public void setTorqueValue(int torqueValue) {
        BoQunTreadmill.getFactory().setFactoryParams(FactoryParams.TORQUE, torqueValue);
    }

    //線電流值
    public void setLineCurrentValue(int lineCurrentValue) {
        BoQunTreadmill.getFactory().setFactoryParams(FactoryParams.LINE_CURRENT, lineCurrentValue);
    }

    //馬達停止模式
    public void setMotorStopMode(int motorStopMode) {
        BoQunTreadmill.getFactory().setFactoryParams(FactoryParams.MOTOR_STOP_MODE, motorStopMode);
    }

    //揚升時間
    public void setInclineTime(int inclineTime) {
        BoQunTreadmill.getFactory().setFactoryParams(FactoryParams.INCLINE_TIME, inclineTime);
    }

    //感應方式
    public void setInductionMethod(int inductionMethod) {
        BoQunTreadmill.getFactory().setFactoryParams(FactoryParams.INDUCTION_METHOD, inductionMethod);
    }

    //公英里切換
    public void setMileSwitch(int mileSwitch) {
        BoQunTreadmill.getFactory().setFactoryParams(FactoryParams.MILE_SWITCH, mileSwitch);
    }

    //心跳接收優先參數
    public void setPA_PB(int PA_PB) {
        BoQunTreadmill.getFactory().setFactoryParams(FactoryParams.PA_PB, PA_PB);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
            handler = null;
        }
        BoQunTreadmill.getFactory().exit();
    }

}
