package com.boqun.serialportdemo.bike;

 class MachineInfo {

    public static  int MIN_LOAD = 1;

    public static  int MAX_LOAD = 1;

     public static  int MIN_INCLINE = 0;

     public static  int MAX_INCLINE = 0;

    public static  int WHEEL_DIAMETER = 0;

    public static  int CLIENT_ID = 0;

    public static  int WATT_GROUP = 0;

    public static  boolean IS_HAVE_INCLINE = false;

    public static  boolean IS_HAVE_FAN = false;

}
