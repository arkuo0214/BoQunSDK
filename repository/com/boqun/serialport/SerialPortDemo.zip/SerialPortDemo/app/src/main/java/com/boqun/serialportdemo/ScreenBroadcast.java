package com.boqun.serialportdemo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

public class ScreenBroadcast extends BroadcastReceiver {

    private ScreenBroadcast.Listener listener;

    private boolean isRegister = false;

    public ScreenBroadcast() {
    }

    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (action != null) {
            if (this.listener != null) {
                if (action.equals("android.intent.action.SCREEN_ON")) {
                    this.listener.onScreenOn();
                } else if (action.equals("android.intent.action.SCREEN_OFF")) {
                    this.listener.onScreenOff();
                }
            }

        }
    }

    public void register(Context context,ScreenBroadcast.Listener listener) {
        this.listener = listener;
        if (isRegister) return;
        isRegister = true;
        IntentFilter filter = new IntentFilter();
        filter.addAction("android.intent.action.SCREEN_OFF");
        filter.addAction("android.intent.action.SCREEN_ON");
        context.registerReceiver(this, filter);
    }

    public void unregister(Context context) {
        if (!isRegister) return;
        isRegister = false;
        context.unregisterReceiver(this);
        this.listener = null;
    }

    public interface Listener {

        void onScreenOn();

        void onScreenOff();
    }
}
