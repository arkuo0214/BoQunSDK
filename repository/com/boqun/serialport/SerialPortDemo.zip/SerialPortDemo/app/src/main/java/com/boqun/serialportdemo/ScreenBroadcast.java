package com.boqun.serialportdemo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

public class ScreenBroadcast extends BroadcastReceiver {
    private static ScreenBroadcast broadcast;
    private ScreenBroadcast.Listener listener;

    public ScreenBroadcast() {
    }

    public static ScreenBroadcast getInstance() {
        if (broadcast == null) {
            broadcast = new ScreenBroadcast();
        }

        return broadcast;
    }

    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (action != null) {
            if (this.listener != null) {
                if (action.equals("android.intent.action.SCREEN_ON")) {
                    this.listener.onScreenOn();
                } else if (action.equals("android.intent.action.SCREEN_OFF")) {
                    this.listener.onScreenOff();
                }
            }

        }
    }

    public void listener(ScreenBroadcast.Listener listener) {
        this.listener = listener;
    }

    public ScreenBroadcast register(Context context) {
        IntentFilter filter = new IntentFilter();
        filter.addAction("android.intent.action.SCREEN_OFF");
        filter.addAction("android.intent.action.SCREEN_ON");
        context.registerReceiver(this, filter);
        return this;
    }

    public void unregister(Context context) {
        context.unregisterReceiver(this);
        this.listener = null;
        broadcast = null;
    }

    public interface Listener {
        void onScreenOn();

        void onScreenOff();
    }
}
