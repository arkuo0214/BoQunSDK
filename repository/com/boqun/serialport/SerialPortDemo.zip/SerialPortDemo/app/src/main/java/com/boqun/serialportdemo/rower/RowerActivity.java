package com.boqun.serialportdemo.rower;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.boqun.serialportdemo.BaseActivity;
import com.boqun.serialportdemo.R;
import com.boqun.serialportdemo.ToastUtil;
import com.boqun.uart.bike.BoQunBike;
import com.boqun.uart.rower.BoQunRower;

import com.boqun.uart.rower.OnRowerDataListener;
import com.boqun.uart.rower.RowerDataBean;
import com.boqun.uart.rower.RowerKeyCode;
import com.boqun.uart.rower.RowerState;


public class RowerActivity extends BaseActivity implements View.OnClickListener {

    private static final String TAG = RowerActivity.class.getSimpleName();

    private TextView mTvInitValue;
    private TextView mTvLoadValue;
    private TextView mTvInclineValue;
    private Button mBtFactory;
    private Button mBtFan;
    private TextView mTvSportValue;
    private Button mBtLoadUp;
    private Button mBtLoadDown;
    private Button mBtStartAndPause;
    private Button mBtStop;
    private Button mBtInclineUp;
    private Button mBtInclineDown;

    private boolean hasFan = false;

    static int MIN_LOAD, MAX_LOAD;

    private boolean isSporting = false;

    private boolean isLocalWatt = false;

    private int currentLoadLevel;

    private int currentFanLevel;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rower_layout);

        initActionBar("Rower Machine", true);

        initViews();

        try {
            BoQunRower.getInstance().init(this, new OnRowerDataListener() {
                @Override
                public void onFanAndWattStateChange(boolean hasFan, boolean isLocalWatt) {
                    RowerActivity.this.hasFan = hasFan;
                    RowerActivity.this.isLocalWatt = isLocalWatt;

                }

                @Override
                public void onLoadRangChange(int minLoad, int maxLoad) {
                    MIN_LOAD = minLoad;
                    MAX_LOAD = maxLoad;
                    currentLoadLevel = minLoad;

                }

                @Override
                public void onInitSuccess() {

                    String str = new StringBuilder()
                            .append("hasFan: ").append(hasFan).append("\n")
                            .append("isLocalWatt: ").append(isLocalWatt).append("\n")
                            .append("minLoad: ").append(MIN_LOAD).append("\n")
                            .append("maxLoad: ").append(MAX_LOAD).append("\n")
                            .append("currentLoadLevel: ").append(currentLoadLevel).append("\n")
                            .toString();

                    Message msg = handler.obtainMessage(1);
                    msg.obj = str;
                    msg.arg1 = currentFanLevel;
                    msg.sendToTarget();
                }

                @Override
                public void onStateChange(@RowerState int state) {
                    String str = (state == RowerState.START ? "Start" : state == RowerState.PAUSE ? "Pause" : state == RowerState.STOP ? "Stop" : "Unknown");

                    Message msg = handler.obtainMessage(3);
                    msg.obj = "SportState：" + str;
                    msg.sendToTarget();
                }

                @Override
                public void onDataChange(RowerDataBean bean) {

                    if (!isLocalWatt) {
                        //When the local watt is not used, the value of the custom watt table can be used, 60 is just an example
                        bean.setWatt(60);
                    }
                    String str = new StringBuilder()
                            .append("Time Value: ").append(bean.getTime()).append("\n")
                            .append("Spm Value: ").append(bean.getSpm()).append("\n")
                            .append("Time/500 Value: ").append(bean.getM500ConsumeTime()).append("\n")
                            .append("Stroke Value: ").append(bean.getStroke()).append("\n")
                            .append("HeartRate Value: ").append(bean.getHeartRate()).append("\n")
                            .append("Distance Value: ").append(bean.getDistance()).append("\n")
                            .append("Calories Value: ").append(bean.getCalories()).append("\n")
                            .append("Watt Value: ").append(bean.getWatt()).toString();

                    Message msg = handler.obtainMessage(2);
                    msg.obj = str;
                    msg.sendToTarget();

                    Log.e(TAG, "onSportData: " + bean.toString());
                }

                @Override
                public void onExternalKeyEvent(@RowerKeyCode int keyCode) {
                    String keyName = "Unknown Key";
                    switch (keyCode) {
                        case RowerKeyCode.FAN:
                            keyName = "Fan key";
                            break;
                        case RowerKeyCode.START_PAUSE:
                            keyName = "Start or Pause Key";
                            break;
                        case RowerKeyCode.STOP:
                            keyName = "Stop key";
                            break;
                        case RowerKeyCode.LOAD_UP:
                            keyName = "Load up key";
                            break;
                        case RowerKeyCode.LOAD_DOWN:
                            keyName = "Load down key";
                            break;
                        default:
                            break;
                    }
                    Message msg = handler.obtainMessage(3);
                    msg.obj = "Press:" + keyName;
                    msg.sendToTarget();

                    Log.e(TAG, "onExternalKeyEvent: " + keyCode);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    private void initViews() {

        mTvInitValue = findViewById(R.id.mTvInitValue);
        mTvLoadValue = findViewById(R.id.mTvLoadValue);
        mTvInclineValue = findViewById(R.id.mTvInclineValue);
        mTvSportValue = findViewById(R.id.mTvSportValue);

        mBtFactory = findViewById(R.id.mBtFactory);
        mBtFan = findViewById(R.id.mBtFan);
        mBtLoadUp = findViewById(R.id.mBtLoadUp);
        mBtLoadDown = findViewById(R.id.mBtLoadDown);
        mBtStartAndPause = findViewById(R.id.mBtStartAndPause);
        mBtStop = findViewById(R.id.mBtStop);

        mBtFactory.setOnClickListener(this);
        mBtFan.setOnClickListener(this);
        mBtLoadUp.setOnClickListener(this);
        mBtLoadDown.setOnClickListener(this);
        mBtStartAndPause.setOnClickListener(this);
        mBtStop.setOnClickListener(this);

    }


    @Override
    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.mBtFactory) {
            startActivity(new Intent(this, RowerFactoryActivity.class));
        } else if (id == R.id.mBtFan) {
            if (hasFan) {
                currentFanLevel = (currentFanLevel < 3) ? currentFanLevel += 1 : 0;
                mBtFan.setText("FAN LEVEL:" + currentFanLevel);

                BoQunBike.setFan(currentFanLevel);
            } else {
                ToastUtil.show(getContext(), "No fan!");
            }
        } else if (id == R.id.mBtLoadUp) {
            if (currentLoadLevel < MAX_LOAD) {
                currentLoadLevel += 1;
                BoQunBike.setLoadValue(currentLoadLevel);
                mTvLoadValue.setText("LOAD:" + currentLoadLevel);
            }
        } else if (id == R.id.mBtLoadDown) {
            if (currentLoadLevel > MIN_LOAD) {
                currentLoadLevel -= 1;
                BoQunBike.setLoadValue(currentLoadLevel);
                mTvLoadValue.setText("LOAD:" + currentLoadLevel);
            }
        } else if (id == R.id.mBtStartAndPause) {
            if (!isSporting) {
                BoQunRower.getInstance().start();
                BoQunRower.getInstance().setLoadLevel(currentLoadLevel, 50);

                mBtStartAndPause.setText("Pause");
            } else {
                BoQunBike.pause();
                mBtStartAndPause.setText("Start");
            }
            isSporting = !isSporting;
        } else if (id == R.id.mBtStop) {
            BoQunRower.getInstance().stop();
            if (isSporting) {
                isSporting = false;
                mBtStartAndPause.setText("Start");
            }
            mTvSportValue.setText("Hello World!");
        }
    }


    private final Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            switch (msg.what) {
                case 1:
                    mTvInitValue.setText((String) msg.obj);
                    mTvLoadValue.setText("LOAD:" + msg.arg1);
                    break;
                case 2:
                    mTvSportValue.setText(String.valueOf(msg.obj));
                    break;
                case 3:
                    ToastUtil.show(getContext(), String.valueOf(msg.obj));
                    break;
                default:
                    break;
            }
            return true;
        }
    });

    public Context getContext() {
        return this;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        BoQunRower.getInstance().destroy();

        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        }

    }
}
