package com.boqun.serialportdemo;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import androidx.annotation.NonNull;

import java.lang.ref.WeakReference;

public abstract class BaseWeakHandler<T> extends Handler {

    private final WeakReference<T> reference;

    public BaseWeakHandler(@NonNull T t) {
        super(Looper.myLooper());
        reference = new WeakReference<>(t);
    }

    public BaseWeakHandler(Looper looper, @NonNull T t) {
        super(looper);
        reference = new WeakReference<>(t);
    }

    @Override
    public void handleMessage(@NonNull Message msg) {
        super.handleMessage(msg);
        if (reference != null) {
            this.handleMessage(msg, reference.get());
        }
    }

    public abstract void handleMessage(@NonNull Message msg, @NonNull T t);

}
