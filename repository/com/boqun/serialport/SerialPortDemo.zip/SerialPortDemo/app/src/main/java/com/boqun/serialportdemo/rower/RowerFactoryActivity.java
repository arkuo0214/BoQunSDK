package com.boqun.serialportdemo.rower;

import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Message;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;

import com.boqun.serialportdemo.BaseActivity;
import com.boqun.serialportdemo.BaseWeakHandler;
import com.boqun.serialportdemo.R;
import com.boqun.serialportdemo.ToastUtil;
import com.boqun.uart.rower.BoQunRowerFactory;
import com.boqun.uart.rower.OnFactoryListener;
import com.boqun.uart.rower.RowerFactoryParams;

public class RowerFactoryActivity extends BaseActivity implements View.OnClickListener {

    private static final String TAG=RowerFactoryActivity.class.getSimpleName();

    private LinearLayout mLiDiameter;
    private TextView mTvDiameterValue;
    private LinearLayout mLiMagnet;
    private TextView mTvMagnetValue;
    private LinearLayout mLiDistance;
    private TextView mTvDistanceValue;
    private LinearLayout mLiCalories;
    private TextView mTvCaloriesValue;
    private LinearLayout mLiPer500MTime;
    private TextView mTvPer500MTimeValue;
    private TextView mTvSaveParameters;
    private ImageView mIvR2RLoadDown;
    private TextView mTvR2RLoadValue;
    private ImageView mIvR2RLoadUp;
    private ImageView mIvR2RAdcDown;
    private TextView mTvR2RAdcValue;
    private ImageView mIvR2RAdcUp;
    private TextView mTvSaveR2R;
    private TextView mTvMotorReturnStatus;
    private TextView mTvMotorReturnCorrection;

    private int mMotorReturnDirection = 0;

    private UIHandler handler = new UIHandler(this);


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rower_factory_layout);

        initActionBar("Rower Machine Factory", true);

        initViews();



        BoQunRowerFactory.getInstance().init(new OnFactoryListener() {
            @Override
            public void onInitialize(@BoQunRowerFactory.Status int status, @BoQunRowerFactory.Direction int direction) {
                mMotorReturnDirection = direction;
                handler.obtainMessage(UPDATE_MOTOR_RETURN_STATUS, status, direction).sendToTarget();
            }

            @Override
            public void onFactoryParamChange(RowerFactoryParams bean) {
                Log.e(TAG, "onFactoryParamChange: "+bean.toString() );

                handler.obtainMessage(UPDATE_VARIOUS_PARAM, bean).sendToTarget();
            }

            @Override
            public void onFactoryLoadAdcChange(int load, int adc) {
                handler.obtainMessage(UPDATE_LOAD_ADC, load, adc).sendToTarget();
            }
        });


    }

    private void initViews() {

        mLiDiameter = findViewById(R.id.mLiDiameter);
        mTvDiameterValue = findViewById(R.id.mTvDiameterValue);
        mLiMagnet = findViewById(R.id.mLiMagnet);
        mTvMagnetValue = findViewById(R.id.mTvMagnetValue);
        mLiDistance = findViewById(R.id.mLiDistance);
        mTvDistanceValue = findViewById(R.id.mTvDistanceValue);
        mLiCalories = findViewById(R.id.mLiCalories);
        mTvCaloriesValue = findViewById(R.id.mTvCaloriesValue);
        mLiPer500MTime = findViewById(R.id.mLiPer500MTime);
        mTvPer500MTimeValue = findViewById(R.id.mTvPer500MTimeValue);
        mTvSaveParameters = findViewById(R.id.mTvSaveParameters);
        mIvR2RLoadDown = findViewById(R.id.mIvR2RLoadDown);
        mTvR2RLoadValue = findViewById(R.id.mTvR2RLoadValue);
        mIvR2RLoadUp = findViewById(R.id.mIvR2RLoadUp);
        mIvR2RAdcDown = findViewById(R.id.mIvR2RAdcDown);
        mTvR2RAdcValue = findViewById(R.id.mTvR2RAdcValue);
        mIvR2RAdcUp = findViewById(R.id.mIvR2RAdcUp);
        mTvSaveR2R = findViewById(R.id.mTvSaveR2R);
        mTvMotorReturnStatus = findViewById(R.id.mTvMotorReturnStatus);
        mTvMotorReturnCorrection = findViewById(R.id.mTvMotorReturnCorrection);

        mLiDiameter.setOnClickListener(this);
        mLiMagnet.setOnClickListener(this);
        mLiDistance.setOnClickListener(this);
        mLiCalories.setOnClickListener(this);
        mLiPer500MTime.setOnClickListener(this);
        mTvSaveParameters.setOnClickListener(this);
        mIvR2RLoadDown.setOnClickListener(this);
        mIvR2RLoadUp.setOnClickListener(this);
        mIvR2RAdcDown.setOnClickListener(this);
        mIvR2RAdcUp.setOnClickListener(this);
        mTvSaveR2R.setOnClickListener(this);
        mTvMotorReturnStatus.setOnClickListener(this);
        mTvMotorReturnCorrection.setOnClickListener(this);

    }


    @Override
    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.mLiDiameter) {
            updateParameter(mTvDiameterValue, "直径");
        } else if (id == R.id.mLiMagnet) {
            updateParameter(mTvMagnetValue, "磁石");
        } else if (id == R.id.mLiDistance) {
            updateParameter(mTvDistanceValue, "距离");
        } else if (id == R.id.mLiCalories) {
            updateParameter(mTvCaloriesValue, "卡路里");
        } else if (id == R.id.mLiPer500MTime) {
            updateParameter(mTvPer500MTimeValue, "TIME/500");
        } else if (id == R.id.mTvSaveParameters) {
            int diameter = Integer.parseInt(mTvDiameterValue.getText().toString());
            int magnet = Integer.parseInt(mTvMagnetValue.getText().toString());
            int distance = Integer.parseInt(mTvDistanceValue.getText().toString());
            int calories = Integer.parseInt(mTvCaloriesValue.getText().toString());
            int per500mTime = Integer.parseInt(mTvPer500MTimeValue.getText().toString());
            BoQunRowerFactory.getInstance().saveParameters(diameter, magnet, distance, calories, per500mTime);
            ToastUtil.show(getContext(), "保存成功！");
        } else if (id == R.id.mIvR2RLoadDown) {
            int load = updateR2RValue(mTvR2RLoadValue, RowerActivity.MIN_LOAD, RowerActivity.MAX_LOAD, -1);
            BoQunRowerFactory.getInstance().queryMotorLoadStroke(load);
        } else if (id == R.id.mIvR2RLoadUp) {
            int load = updateR2RValue(mTvR2RLoadValue, RowerActivity.MIN_LOAD, RowerActivity.MAX_LOAD, 1);
            BoQunRowerFactory.getInstance().queryMotorLoadStroke(load);
        } else if (id == R.id.mIvR2RAdcDown) {
            updateR2RValue(mTvR2RAdcValue, 0, 999, -1);
        } else if (id == R.id.mIvR2RAdcUp) {
            updateR2RValue(mTvR2RAdcValue, 0, 999, 1);
        } else if (id == R.id.mTvSaveR2R) {

            int load = Integer.parseInt(mTvR2RLoadValue.getText().toString());
            int adc = Integer.parseInt(mTvR2RAdcValue.getText().toString());
            BoQunRowerFactory.getInstance().saveMotorStroke(load, adc);
            ToastUtil.show(getContext(), "保存成功！");
        } else if (id == R.id.mTvMotorReturnCorrection) {

            BoQunRowerFactory.getInstance().setRepairMotorDirection(mMotorReturnDirection);
            if (mMotorReturnDirection == BoQunRowerFactory.Direction.UP) {
                ToastUtil.show(getContext(), "修复方向：UP");
            } else if (mMotorReturnDirection == BoQunRowerFactory.Direction.DOWN) {
                ToastUtil.show(getContext(), "修复方向：DOWN");
            }
        }
    }


    private void updateParameter(final TextView view, String s) {
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_NORMAL);
        et.setMaxLines(1);
        new AlertDialog.Builder(this).setTitle(s)
                .setIcon(android.R.drawable.sym_def_app_icon)
                .setView(et)
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        view.setText(et.getText().toString());
                    }
                }).setNegativeButton("Cancel", null).show();
    }

    private int updateR2RValue(TextView view, int min, int max, int value) {
        int r2rLoadValue = Integer.parseInt(view.getText().toString());
        int v = r2rLoadValue + value;
        if (v < min) {
            v = min;
        } else if (v > max) {
            v = max;
        }
        view.setText(String.valueOf(v));
        return v;
    }

    private void updateMotorReturnStatus(int status) {
        if (status == BoQunRowerFactory.Status.E2) {
            mTvMotorReturnStatus.setText("E2");
            mTvMotorReturnCorrection.setEnabled(true);
            mTvMotorReturnCorrection.setVisibility(View.VISIBLE);
        } else {
            mTvMotorReturnStatus.setText("Normal");
            mTvMotorReturnCorrection.setEnabled(false);
            mTvMotorReturnCorrection.setVisibility(View.GONE);
        }
    }

    private void updateVariousParam(RowerFactoryParams bean) {
        mTvDiameterValue.setText(String.valueOf(bean.getDiameter()));
        mTvMagnetValue.setText(String.valueOf(bean.getMagnet()));
        mTvDistanceValue.setText(String.valueOf(bean.getDistance()));
        mTvCaloriesValue.setText(String.valueOf(bean.getCalories()));
        mTvPer500MTimeValue.setText(String.valueOf(bean.getPer500MTime()));
    }

    private void updateMotorAdcValue(int load, int adc) {
        mTvR2RLoadValue.setText(String.valueOf(load));
        mTvR2RAdcValue.setText(String.valueOf(adc));
    }

    private static final int UPDATE_MOTOR_RETURN_STATUS = 1;

    private static final int UPDATE_VARIOUS_PARAM = 2;

    private static final int UPDATE_LOAD_ADC = 3;

    private static class UIHandler extends BaseWeakHandler<RowerFactoryActivity> {

        public UIHandler(@NonNull RowerFactoryActivity activity) {
            super(activity);
        }

        @Override
        public void handleMessage(@NonNull Message msg, @NonNull RowerFactoryActivity activity) {
            switch (msg.what) {
                case UPDATE_MOTOR_RETURN_STATUS:
                    activity.updateMotorReturnStatus(msg.arg1);
                    break;
                case UPDATE_VARIOUS_PARAM:
                    activity.updateVariousParam((RowerFactoryParams) msg.obj);
                    break;
                case UPDATE_LOAD_ADC:
                    activity.updateMotorAdcValue(msg.arg1, msg.arg2);
                    break;
                default:
                    break;
            }
        }
    }

    @Override
    protected void onDestroy() {

        BoQunRowerFactory.getInstance().exit();

        super.onDestroy();
    }
}
