package com.boqun.serialportdemo;

import android.content.Context;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class BaseActivity extends AppCompatActivity {


    public void initActionBar(CharSequence text, boolean showHomeAsUp) {
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle(text);
        actionBar.setDisplayHomeAsUpEnabled(showHomeAsUp);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public Context getContext(){
        return this;
    }
}
