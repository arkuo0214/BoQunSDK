package com.boqun.serialportdemo;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.boqun.serialportdemo.bike.BikeActivity;
import com.boqun.serialportdemo.treadmill.TreadmillActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = MainActivity.class.getSimpleName();

    private Button mBtBikeTest;
    private Button mBtTreadmillTest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mBtBikeTest = findViewById(R.id.mBtBikeTest);
        mBtTreadmillTest = findViewById(R.id.mBtTreadmillTest);

        mBtBikeTest.setOnClickListener(this);
        mBtTreadmillTest.setOnClickListener(this);

        Log.e(TAG,"decompilePackageName:"+decompilePackageName("^jh)]jlpi)n`md\\gkjmo_`hj"));
        Log.e(TAG,"decompilePackageName:"+decompilePackageName("^jh)cp\\r`d)cdbth)_`hj\\kk"));
        Log.e(TAG,"decompilePackageName:"+decompilePackageName("^jh)d^jinjg`)oao"));

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mBtBikeTest:
                startActivity(new Intent(this, BikeActivity.class));
                finish();
                break;
            case R.id.mBtTreadmillTest:
                startActivity(new Intent(this, TreadmillActivity.class));
                finish();
                break;
            default:
                break;
        }
    }

    private static String formatPackageName(String packageName) {
        char[] chars = new char[packageName.length()];

        packageName.getChars(0, packageName.length(), chars, 0);

        for (int i = 0; i < chars.length; i++) {
            chars[i] -= 5;
        }
        return new String(chars);
    }


    private static String decompilePackageName(String packageName) {
        char[] chars = new char[packageName.length()];

        packageName.getChars(0, packageName.length(), chars, 0);

        for (int i = 0; i < chars.length; i++) {
            chars[i] += 5;
        }
        return new String(chars);
    }
}
