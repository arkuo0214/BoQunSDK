package com.boqun.serialportdemo.treadmill;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.boqun.serialportdemo.R;
import com.boqun.serialportdemo.ScreenBroadcast;
import com.boqun.uart.treadmill.BoQunTreadmill;
import com.boqun.uart.treadmill.OnTreadmillDataListener;
import com.boqun.uart.treadmill.SafetyKeyState;
import com.boqun.uart.treadmill.TreadmillKeyCode;
import com.boqun.uart.treadmill.TreadmillState;
import com.boqun.uart.treadmill.TreadmillWorkMode;

public class TreadmillActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = TreadmillActivity.class.getSimpleName();

    private TextView mTvInitValue;
    private TextView mTvSpeedValue;
    private TextView mTvInclineValue;
    private Button mBtFactory;
    private Button mBtFan;
    private TextView mTvSportValue;
    private Button mBtSpeedUp;
    private Button mBtSpeedDown;
    private Button mBtStartAndPause;
    private Button mBtStop;
    private Button mBtInclineUp;
    private Button mBtInclineDown;

    private int currentFanLevel = 0;
    private int currentSpeed = 0, currentIncline = 0;
    private boolean mSecurityLeyFallsOff = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_treadmill_main);

        mTvInitValue = findViewById(R.id.mTvInitValue);
        mTvSpeedValue = findViewById(R.id.mTvSpeedValue);
        mTvInclineValue = findViewById(R.id.mTvInclineValue);
        mBtFactory = findViewById(R.id.mBtFactory);
        mBtFan = findViewById(R.id.mBtFan);
        mTvSportValue = findViewById(R.id.mTvSportValue);
        mBtSpeedUp = findViewById(R.id.mBtSpeedUp);
        mBtSpeedDown = findViewById(R.id.mBtSpeedDown);
        mBtStartAndPause = findViewById(R.id.mBtStartAndPause);
        mBtStop = findViewById(R.id.mBtStop);
        mBtInclineUp = findViewById(R.id.mBtInclineUp);
        mBtInclineDown = findViewById(R.id.mBtInclineDown);

        mBtStartAndPause.setOnClickListener(this);
        mBtStop.setOnClickListener(this);
        mBtSpeedUp.setOnClickListener(this);
        mBtSpeedDown.setOnClickListener(this);
        mBtInclineUp.setOnClickListener(this);
        mBtInclineDown.setOnClickListener(this);
        mBtFactory.setOnClickListener(this);
        mBtFan.setOnClickListener(this);

        try {
            BoQunTreadmill.init(this, new OnTreadmillDataListener() {
                @Override
                public void onReadWattGroup(int wattGroup) {
                    MachineInfo.WATT_GROUP = wattGroup;
                }

                @Override
                public void onReadControlConfig(int minIncline, int maxIncline, int minSpeed, int maxSpeed, int chipSpeed, boolean hanIncline, boolean hasFan) {
                    StringBuilder builder = new StringBuilder();

                    MachineInfo.MIN_INCLINE = minIncline;
                    MachineInfo.MAX_INCLINE = maxIncline;
                    MachineInfo.MIN_SPEED = minSpeed;
                    MachineInfo.MAX_SPEED = maxSpeed;
                    MachineInfo.CHIP_SPEED = chipSpeed;
                    MachineInfo.IS_HAVE_INCLINE = hanIncline;
                    MachineInfo.IS_HAVE_FAN = hasFan;

                    builder.append("\r\n").append("Min Speed： ").append(MachineInfo.MIN_SPEED);
                    builder.append("\r\n").append("Max Speed： ").append(MachineInfo.MAX_SPEED);
                    builder.append("\r\n").append("Chip Speed： ").append(MachineInfo.CHIP_SPEED);
                    builder.append("\r\n").append("Is there a fan： ").append((MachineInfo.IS_HAVE_FAN ? "Yes" : "No"));
                    builder.append("\r\n").append("Is there a incline： ").append((MachineInfo.IS_HAVE_INCLINE ? "Yes" : "No"));
                    builder.append("\r\n").append("Min Incline： ").append(MachineInfo.MIN_INCLINE);
                    builder.append("\r\n").append("Max Incline： ").append(MachineInfo.MAX_INCLINE);

                    Message msg = handler.obtainMessage(1);
                    msg.obj = builder.toString();
                    msg.sendToTarget();

                    Log.e(TAG, "onReadControlConfig: " + builder.toString());
                }

                @Override
                public void onInitSuccess() {
                    Log.e(TAG, "onInitSuccess");
                }

                @Override
                public void onStateChange(int state) {
                    String str = (state == TreadmillState.START ? "Start" : state == TreadmillState.PAUSE ? "Pause" : state == TreadmillState.STOP ? "Stop" : "Unknown");

                    Message msg = handler.obtainMessage(3);
                    msg.obj = "SportState：" + str;
                    msg.sendToTarget();

                    Log.e(TAG, "onStateChange: " + str);
                }

                @Override
                public void onDataChange(int state, int heartRate, int speed) {
                    if (state == SafetyKeyState.NORMAL) {
                        if (mSecurityLeyFallsOff) {
                            BoQunTreadmill.setWorkMode(TreadmillWorkMode.WAKE);
                            mSecurityLeyFallsOff = false;
                        }
                    } else if (state == SafetyKeyState.UNPLUG) {
                        BoQunTreadmill.setWorkMode(TreadmillWorkMode.SAFE_LOCK);
                        mSecurityLeyFallsOff = true;
                    }

                    StringBuilder builder = new StringBuilder();
                    builder.append("\r\n").append("Safety Key State： ").append((state == SafetyKeyState.NORMAL ? "NORMAL" : state == SafetyKeyState.UNPLUG ? "UNPLUG" : "Unknown"));
                    builder.append("\r\n").append("PULSE Value： ").append(heartRate);
                    builder.append("\r\n").append("Speed Value： ").append(speed);

                    Message msg = handler.obtainMessage(2);
                    msg.obj = builder.toString();
                    msg.sendToTarget();

                    Log.e(TAG, "onDataChange: " + builder.toString());
                }

                @Override
                public void onExternalKeyEvent(int keyCode) {
                    String keyName = "Unknown Key";
                    switch (keyCode) {
                        case TreadmillKeyCode.START_PAUSE:
                            keyName = "Start or Pause Key";
                            break;
                        case TreadmillKeyCode.STOP:
                            keyName = "Stop key";
                            break;
                        case TreadmillKeyCode.SPEED_UP:
                            keyName = "Speed Up key";
                            break;
                        case TreadmillKeyCode.SPEED_DOWN:
                            keyName = "Speed Down Key";
                            break;
                        case TreadmillKeyCode.INCLINE_UP:
                            keyName = "Incline Up Key";
                            break;
                        case TreadmillKeyCode.INCLINE_DOWN:
                            keyName = "Incline Down Key";
                            break;
                        case TreadmillKeyCode.FAN:
                            keyName = "Fan Key";
                            break;
                        case TreadmillKeyCode.COOL_DOWN:
                            keyName = "Cool Down Mode Key";
                            break;
                        case TreadmillKeyCode.VOLUME_UP:
                            keyName = "Volume Up Key";
                            break;
                        case TreadmillKeyCode.VOLUME_DOWN:
                            keyName = "Volume Down Key";
                            break;
                        default:
                            break;
                    }

                    Message msg = handler.obtainMessage(3);
                    msg.obj = "Press:" + keyName;
                    msg.sendToTarget();

                    Log.e(TAG, "onExternalKeyEvent: " + keyCode);
                }

                @Override
                public void onExternalFastSpeed(int speed) {
                    Message msg = handler.obtainMessage(3);
                    msg.obj = "Press Speed Value:" + speed;
                    msg.sendToTarget();

                    Log.e(TAG, "onExternalKeyEvent: " + speed);
                }

                @Override
                public void onExternalFastIncline(int incline) {
                    Message msg = handler.obtainMessage(3);
                    msg.obj = "Press Speed Value:" + incline;
                    msg.sendToTarget();

                    Log.e(TAG, "onExternalKeyEvent: " + incline);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

        ScreenBroadcast.getInstance().register(this).listener(new ScreenBroadcast.Listener() {
            @Override
            public void onScreenOn() {
                Log.e(TAG, "onScreenOn");
                BoQunTreadmill.setWorkMode(TreadmillWorkMode.WAKE);
            }

            @Override
            public void onScreenOff() {
                Log.e(TAG, "onScreenOff");
                BoQunTreadmill.setWorkMode(TreadmillWorkMode.SLEEP);
            }
        });
    }

    private int isSporting = 0; //0=stop/1=start/2=pause

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mBtStartAndPause:
                if (isSporting == 0) {
                    BoQunTreadmill.start();
                    currentSpeed = MachineInfo.MIN_SPEED;
                    BoQunTreadmill.setCurrentSpeed(currentSpeed, 50);
                    if (MachineInfo.IS_HAVE_INCLINE) {
                        BoQunTreadmill.setCurrentIncline(currentIncline, 100);
                    }
                    mBtStartAndPause.setText("Pause");
                    isSporting = 1;
                } else if (isSporting == 2) {
                    BoQunTreadmill.start();
                    BoQunTreadmill.setCurrentSpeed(currentSpeed, 50);
                    if (MachineInfo.IS_HAVE_INCLINE) {
                        BoQunTreadmill.setCurrentIncline(currentIncline, 100);
                    }
                    mBtStartAndPause.setText("Pause");
                    isSporting = 1;
                }
                else {
                    BoQunTreadmill.pause();
                    mBtStartAndPause.setText("Start");
                    isSporting = 2;
                }
                mTvSpeedValue.setText("SPEED:" + currentSpeed);
                break;
            case R.id.mBtStop:
                BoQunTreadmill.stop();

                isSporting = 0;

                currentSpeed = 0;
                currentIncline = MachineInfo.MIN_INCLINE;

                mTvSpeedValue.setText("SPEED:" + currentSpeed);
                mTvInclineValue.setText("INCLINE:" + currentIncline);
                mBtStartAndPause.setText("Start");
                break;
            case R.id.mBtSpeedUp:
                if (currentSpeed < MachineInfo.MAX_SPEED) {
                    currentSpeed += MachineInfo.CHIP_SPEED;
                    BoQunTreadmill.setCurrentSpeed(currentSpeed);
                    mTvSpeedValue.setText("SPEED:" + currentSpeed);
                }
                break;
            case R.id.mBtSpeedDown:
                if (currentSpeed > MachineInfo.MIN_SPEED) {
                    currentSpeed -= MachineInfo.CHIP_SPEED;
                    BoQunTreadmill.setCurrentSpeed(currentSpeed);
                    mTvSpeedValue.setText("SPEED:" + currentSpeed);
                }
                break;
            case R.id.mBtInclineUp:
                if (currentIncline < MachineInfo.MAX_INCLINE) {
                    currentIncline += 1;
                    BoQunTreadmill.setCurrentInline(currentIncline);
                    mTvInclineValue.setText("INCLINE:" + currentIncline);
                }
                break;
            case R.id.mBtInclineDown:
                if (currentIncline > MachineInfo.MIN_INCLINE) {
                    currentIncline -= 1;
                    BoQunTreadmill.setCurrentInline(currentIncline);
                    mTvInclineValue.setText("INCLINE:" + currentIncline);
                }

                break;
            case R.id.mBtFan:
                if (MachineInfo.IS_HAVE_FAN) {
                    currentFanLevel = (currentFanLevel < 3) ? currentFanLevel += 1 : 0;
                    mBtFan.setText("FAN LEVEL:" + currentFanLevel);

                    BoQunTreadmill.setFanLevel(currentFanLevel);
                } else {
                    ToastUtil.show(getContext(), "No fan!");
                }
                break;
            case R.id.mBtFactory:
                startActivity(new Intent(this, FactoryActivity.class));
                break;
            default:
                break;
        }

    }

    private Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            switch (msg.what) {
                case 1:
                    mTvInitValue.setText(String.valueOf(msg.obj));
                    mTvSpeedValue.setText("SPEED:" + currentSpeed);
                    mTvInclineValue.setText("INCLINE:" + currentIncline);
                    break;
                case 2:
                    mTvSportValue.setText(String.valueOf(msg.obj));
                    break;
                case 3:
                    ToastUtil.show(getContext(), String.valueOf(msg.obj));
                    break;
                default:
                    break;
            }
            return true;
        }
    });

    public Context getContext() {
        return this;
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
            handler = null;
        }
        BoQunTreadmill.destroy();
    }
}
